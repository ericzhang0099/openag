"""
A2A Protocol - Agent to Agent Communication

实现Agent之间的通讯协议:
- 消息格式定义
- 消息编解码
- 加密传输
- 消息路由
"""

import json
import time
import uuid
import hashlib
from enum import Enum
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


class MessageType(str, Enum):
    """消息类型"""
    TEXT = "text"
    COMMAND = "command"
    FILE = "file"
    TRANSACTION = "transaction"
    HEARTBEAT = "heartbeat"
    DISCOVERY = "discovery"


class MessagePriority(str, Enum):
    """消息优先级"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


@dataclass
class AgentId:
    """Agent ID"""
    agent_id: str
    name: str
    public_key: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "public_key": self.public_key
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "AgentId":
        return cls(
            agent_id=data.get("agent_id", ""),
            name=data.get("name", ""),
            public_key=data.get("public_key")
        )


@dataclass
class A2AMessage:
    """A2A消息"""
    message_id: str
    sender: AgentId
    recipient: AgentId
    message_type: MessageType
    content: str
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: float = field(default_factory=time.time)
    ttl: int = 300  # 5分钟
    encrypted: bool = False
    signature: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.message_id:
            self.message_id = str(uuid.uuid4())
    
    def to_dict(self) -> Dict:
        return {
            "message_id": self.message_id,
            "sender": self.sender.to_dict(),
            "recipient": self.recipient.to_dict(),
            "message_type": self.message_type.value,
            "content": self.content,
            "priority": self.priority.value,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
            "encrypted": self.encrypted,
            "signature": self.signature,
            "metadata": self.metadata
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: Dict) -> "A2AMessage":
        return cls(
            message_id=data.get("message_id", ""),
            sender=AgentId.from_dict(data.get("sender", {})),
            recipient=AgentId.from_dict(data.get("recipient", {})),
            message_type=MessageType(data.get("message_type", "text")),
            content=data.get("content", ""),
            priority=MessagePriority(data.get("priority", "normal")),
            timestamp=data.get("timestamp", time.time()),
            ttl=data.get("ttl", 300),
            encrypted=data.get("encrypted", False),
            signature=data.get("signature"),
            metadata=data.get("metadata", {})
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> "A2AMessage":
        return cls.from_dict(json.loads(json_str))
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        return time.time() - self.timestamp > self.ttl
    
    def get_hash(self) -> str:
        """计算消息哈希"""
        data = f"{self.message_id}{self.sender.agent_id}{self.recipient.agent_id}{self.content}"
        return hashlib.sha256(data.encode()).hexdigest()


class AgentRegistry:
    """Agent注册表"""
    
    def __init__(self):
        self._agents: Dict[str, AgentId] = {}
        self._last_seen: Dict[str, float] = {}
    
    def register(self, agent: AgentId) -> None:
        """注册Agent"""
        self._agents[agent.agent_id] = agent
        self._last_seen[agent.agent_id] = time.time()
    
    def unregister(self, agent_id: str) -> None:
        """注销Agent"""
        if agent_id in self._agents:
            del self._agents[agent_id]
        if agent_id in self._last_seen:
            del self._last_seen[agent_id]
    
    def get(self, agent_id: str) -> Optional[AgentId]:
        """获取Agent"""
        return self._agents.get(agent_id)
    
    def list_all(self) -> List[AgentId]:
        """列出所有Agent"""
        return list(self._agents.values())
    
    def heartbeat(self, agent_id: str) -> None:
        """更新心跳"""
        self._last_seen[agent_id] = time.time()
    
    def get_online(self, timeout: float = 60) -> List[AgentId]:
        """获取在线Agent"""
        now = time.time()
        return [
            agent for agent in self._agents.values()
            if now - self._last_seen.get(agent.agent_id, 0) < timeout
        ]


class MessageQueue:
    """消息队列"""
    
    def __init__(self, max_size: int = 1000):
        self._queue: List[A2AMessage] = []
        self._max_size = max_size
    
    def enqueue(self, message: A2AMessage) -> bool:
        """入队"""
        if len(self._queue) >= self._max_size:
            return False
        self._queue.append(message)
        return True
    
    def dequeue(self) -> Optional[A2AMessage]:
        """出队"""
        if not self._queue:
            return None
        return self._queue.pop(0)
    
    def peek(self) -> Optional[A2AMessage]:
        """查看队首"""
        if not self._queue:
            return None
        return self._queue[0]
    
    def get_for_recipient(self, agent_id: str) -> List[A2AMessage]:
        """获取指定接收人的消息"""
        return [
            msg for msg in self._queue
            if msg.recipient.agent_id == agent_id
        ]
    
    def remove_expired(self) -> int:
        """移除过期消息"""
        original = len(self._queue)
        self._queue = [msg for msg in self._queue if not msg.is_expired()]
        return original - len(self._queue)
    
    def size(self) -> int:
        """队列大小"""
        return len(self._queue)


class A2AProtocol:
    """A2A协议"""
    
    def __init__(self):
        self.registry = AgentRegistry()
        self.message_queue = MessageQueue()
    
    def create_message(
        self,
        sender: AgentId,
        recipient: AgentId,
        content: str,
        message_type: MessageType = MessageType.TEXT,
        priority: MessagePriority = MessagePriority.NORMAL
    ) -> A2AMessage:
        """创建消息"""
        return A2AMessage(
            message_id=str(uuid.uuid4()),
            sender=sender,
            recipient=recipient,
            message_type=message_type,
            content=content,
            priority=priority
        )
    
    def send(self, message: A2AMessage) -> bool:
        """发送消息"""
        # 验证消息
        if not self._validate_message(message):
            return False
        
        # 加入队列
        return self.message_queue.enqueue(message)
    
    def receive(self, agent_id: str) -> List[A2AMessage]:
        """接收消息"""
        messages = self.message_queue.get_for_recipient(agent_id)
        # 移除已接收的消息
        for msg in messages:
            self.message_queue._queue.remove(msg)
        return messages
    
    def _validate_message(self, message: A2AMessage) -> bool:
        """验证消息"""
        if not message.sender.agent_id:
            return False
        if not message.recipient.agent_id:
            return False
        if not message.content:
            return False
        return True
    
    def broadcast(self, sender: AgentId, content: str) -> int:
        """广播消息"""
        count = 0
        for agent in self.registry.list_all():
            if agent.agent_id != sender.agent_id:
                msg = self.create_message(sender, agent, content)
                if self.send(msg):
                    count += 1
        return count
