"""
AGC Token - Agent Gold Coin

实现AGC代币功能:
- 钱包创建/导入
- 余额查询
- 转账交易
- 交易记录
"""

import json
import time
import uuid
import hashlib
import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


class TransactionType(str, Enum):
    """交易类型"""
    TRANSFER = "transfer"
    RECEIVE = "receive"
    MINT = "mint"
    BURN = "burn"
    STAKE = "stake"
    UNSTAKE = "unstake"


class TransactionStatus(str, Enum):
    """交易状态"""
    PENDING = "pending"
    CONFIRMED = "confirmed"
    FAILED = "failed"


@dataclass
class Wallet:
    """钱包"""
    wallet_id: str
    agent_id: str
    address: str
    balance: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "wallet_id": self.wallet_id,
            "agent_id": self.agent_id,
            "address": self.address,
            "balance": self.balance,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "Wallet":
        return cls(
            wallet_id=data.get("wallet_id", ""),
            agent_id=data.get("agent_id", ""),
            address=data.get("address", ""),
            balance=data.get("balance", 0),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
            metadata=data.get("metadata", {})
        )


@dataclass
class Transaction:
    """交易"""
    tx_id: str
    wallet_id: str
    from_address: str
    to_address: str
    amount: int
    transaction_type: TransactionType
    status: TransactionStatus = TransactionStatus.PENDING
    fee: int = 0
    timestamp: float = field(default_factory=time.time)
    confirmed_at: Optional[float] = None
    block_height: Optional[int] = None
    signature: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.tx_id:
            self.tx_id = f"tx_{uuid.uuid4().hex[:16]}"
    
    def to_dict(self) -> Dict:
        return {
            "tx_id": self.tx_id,
            "wallet_id": self.wallet_id,
            "from_address": self.from_address,
            "to_address": self.to_address,
            "amount": self.amount,
            "transaction_type": self.transaction_type.value,
            "status": self.status.value,
            "fee": self.fee,
            "timestamp": self.timestamp,
            "confirmed_at": self.confirmed_at,
            "block_height": self.block_height,
            "signature": self.signature,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "Transaction":
        return cls(
            tx_id=data.get("tx_id", ""),
            wallet_id=data.get("wallet_id", ""),
            from_address=data.get("from_address", ""),
            to_address=data.get("to_address", ""),
            amount=data.get("amount", 0),
            transaction_type=TransactionType(data.get("transaction_type", "transfer")),
            status=TransactionStatus(data.get("status", "pending")),
            fee=data.get("fee", 0),
            timestamp=data.get("timestamp", time.time()),
            confirmed_at=data.get("confirmed_at"),
            block_height=data.get("block_height"),
            signature=data.get("signature"),
            metadata=data.get("metadata", {})
        )
    
    def get_hash(self) -> str:
        """计算交易哈希"""
        data = f"{self.tx_id}{self.from_address}{self.to_address}{self.amount}{self.timestamp}"
        return hashlib.sha256(data.encode()).hexdigest()


class WalletManager:
    """钱包管理器"""
    
    def __init__(self):
        self._wallets: Dict[str, Wallet] = {}
        self._transactions: Dict[str, Transaction] = {}
        self._pending_txs: Dict[str, asyncio.Future] = {}
    
    def create_wallet(self, agent_id: str) -> Wallet:
        """创建钱包"""
        # 生成地址
        address = self._generate_address(agent_id)
        
        wallet = Wallet(
            wallet_id=f"wallet_{uuid.uuid4().hex[:16]}",
            agent_id=agent_id,
            address=address,
            balance=0
        )
        
        self._wallets[wallet.wallet_id] = wallet
        self._wallets[address] = wallet  # 按地址索引
        
        return wallet
    
    def import_wallet(self, agent_id: str, address: str) -> Wallet:
        """导入钱包"""
        # 检查地址是否已存在
        if address in self._wallets:
            return self._wallets[address]
        
        wallet = Wallet(
            wallet_id=f"wallet_{uuid.uuid4().hex[:16]}",
            agent_id=agent_id,
            address=address
        )
        
        self._wallets[wallet.wallet_id] = wallet
        self._wallets[address] = wallet
        
        return wallet
    
    def get_wallet(self, wallet_id: str) -> Optional[Wallet]:
        """获取钱包"""
        return self._wallets.get(wallet_id)
    
    def get_wallet_by_address(self, address: str) -> Optional[Wallet]:
        """通过地址获取钱包"""
        return self._wallets.get(address)
    
    def get_wallet_by_agent(self, agent_id: str) -> Optional[Wallet]:
        """通过Agent ID获取钱包"""
        for wallet in self._wallets.values():
            if wallet.agent_id == agent_id:
                return wallet
        return None
    
    def _generate_address(self, agent_id: str) -> str:
        """生成地址"""
        seed = f"{agent_id}:{time.time()}"
        hash_obj = hashlib.sha256(seed.encode())
        return f"AGC{hash_obj.hexdigest()[:40]}"
    
    async def transfer(
        self,
        from_wallet_id: str,
        to_address: str,
        amount: int,
        fee: int = 100
    ) -> Optional[Transaction]:
        """转账"""
        # 获取钱包
        from_wallet = self.get_wallet(from_wallet_id)
        if not from_wallet:
            return None
        
        # 检查余额
        if from_wallet.balance < amount + fee:
            return None
        
        # 创建交易
        tx = Transaction(
            tx_id=f"tx_{uuid.uuid4().hex[:16]}",
            wallet_id=from_wallet_id,
            from_address=from_wallet.address,
            to_address=to_address,
            amount=amount,
            transaction_type=TransactionType.TRANSFER,
            fee=fee
        )
        
        # 扣款
        from_wallet.balance -= (amount + fee)
        from_wallet.updated_at = time.time()
        
        # 保存交易
        self._transactions[tx.tx_id] = tx
        
        # 模拟确认
        asyncio.create_task(self._confirm_transaction(tx.tx_id))
        
        return tx
    
    async def _confirm_transaction(self, tx_id: str) -> None:
        """确认交易"""
        await asyncio.sleep(2)  # 模拟确认时间
        
        tx = self._transactions.get(tx_id)
        if not tx:
            return
        
        # 更新状态
        tx.status = TransactionStatus.CONFIRMED
        tx.confirmed_at = time.time()
        
        # 增加接收方余额
        to_wallet = self.get_wallet_by_address(tx.to_address)
        if to_wallet:
            to_wallet.balance += tx.amount
            to_wallet.updated_at = time.time()
        
        # 完成等待
        if tx_id in self._pending_txs:
            self._pending_txs[tx_id].set_result(tx)
    
    def get_balance(self, wallet_id: str) -> int:
        """获取余额"""
        wallet = self.get_wallet(wallet_id)
        return wallet.balance if wallet else 0
    
    def get_transactions(
        self,
        wallet_id: str,
        limit: int = 50
    ) -> List[Transaction]:
        """获取交易记录"""
        txs = [
            tx for tx in self._transactions.values()
            if tx.wallet_id == wallet_id
        ]
        txs.sort(key=lambda x: x.timestamp, reverse=True)
        return txs[:limit]
    
    def get_pending_transactions(self, wallet_id: str) -> List[Transaction]:
        """获取待确认交易"""
        return [
            tx for tx in self._transactions.values()
            if tx.wallet_id == wallet_id and tx.status == TransactionStatus.PENDING
        ]
    
    def generate_qr_code(self, wallet_id: str) -> str:
        """生成收款码"""
        wallet = self.get_wallet(wallet_id)
        if not wallet:
            return ""
        
        # 生成包含地址的JSON
        data = {
            "type": "agc_payment",
            "address": wallet.address,
            "agent_id": wallet.agent_id
        }
        return json.dumps(data)
    
    def parse_qr_code(self, qr_data: str) -> Optional[Dict]:
        """解析收款码"""
        try:
            data = json.loads(qr_data)
            if data.get("type") == "agc_payment":
                return {
                    "address": data.get("address"),
                    "agent_id": data.get("agent_id")
                }
        except:
            pass
        return None


class AGCClient:
    """AGC客户端"""
    
    def __init__(self):
        self.wallet_manager = WalletManager()
        self._connected = False
        self._network = "mainnet"
    
    async def connect(self, node_url: str) -> bool:
        """连接到AGC网络"""
        # 模拟连接
        self._connected = True
        return True
    
    def disconnect(self) -> None:
        """断开连接"""
        self._connected = False
    
    def is_connected(self) -> bool:
        """检查连接"""
        return self._connected
    
    def set_network(self, network: str) -> None:
        """设置网络"""
        self._network = network
    
    def get_network(self) -> str:
        """获取网络"""
        return self._network
    
    async def sync_balance(self, wallet_id: str) -> int:
        """同步余额"""
        # 模拟从网络获取余额
        wallet = self.wallet_manager.get_wallet(wallet_id)
        if wallet:
            return wallet.balance
        return 0
    
    async def broadcast_transaction(self, tx: Transaction) -> bool:
        """广播交易"""
        if not self._connected:
            return False
        # 模拟广播
        return True
