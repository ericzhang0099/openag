"""
Discord Style - More Screens

更多Discord风格页面:
- 语音频道
- 视频通话
- 用户资料
- 表情反应
- 成员列表
"""

import 'package:flutter/material.dart';

class DiscordTheme {
  static const Color background = Color(0xFF313338);
  static const Color channelList = Color(0xFF2B2D31);
  static const Color sidebar = Color(0xFF1E1F22);
  static const Color messageBar = Color(0xFF383A40);
  static const Color primary = Color(0xFF5865F2);
  static const Color success = Color(0xFF23A55A);
  static const Color danger = Color(0xFFF23F43);
  static const Color warning = Color(0xFFF0B232);
  static const Color textNormal = Color(0xFFDBDEE1);
  static const Color textMuted = Color(0xFF949BA4);
  static const Color divider = Color(0xFF1E1F22);
}

// ==================== 语音频道页面 ====================

class DiscordVoiceChannelScreen extends StatelessWidget {
  const DiscordVoiceChannelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: Row(
          children: [
            Icon(Icons.volume_up, color: DiscordTheme.textMuted, size: 18),
            const SizedBox(width: 8),
            const Text('语音频道', style: TextStyle(color: DiscordTheme.textNormal, fontSize: 16)),
          ],
        ),
      ),
      body: Column(
        children: [
          // 语音频道列表
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildVoiceChannel('🎮 游戏讨论', [
                  {'name': 'Agent-Alice', 'status': '正在玩王者荣耀', 'muted': false, 'deaf': false},
                  {'name': 'Agent-Bob', 'status': '空闲', 'muted': true, 'deaf': false},
                ]),
                const SizedBox(height: 16),
                _buildVoiceChannel('💻 技术交流', [
                  {'name': 'Agent-Carol', 'status': '正在编程', 'muted': false, 'deaf': false},
                ]),
                const SizedBox(height: 16),
                _buildVoiceChannel('🎵 音乐分享', []),
              ],
            ),
          ),
          
          // 底部控制栏
          _buildControlBar(),
        ],
      ),
    );
  }

  Widget _buildVoiceChannel(String name, List<Map<String, dynamic>> members) {
    return Container(
      decoration: BoxDecoration(
        color: DiscordTheme.channelList,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(Icons.volume_up, color: DiscordTheme.textMuted, size: 16),
                const SizedBox(width: 8),
                Text(name, style: const TextStyle(color: DiscordTheme.textNormal, fontWeight: FontWeight.bold)),
                const Spacer(),
                Icon(Icons.person_add, color: DiscordTheme.textMuted, size: 18),
              ],
            ),
          ),
          if (members.isNotEmpty)
            ...members.map((m) => _buildVoiceMember(m)),
        ],
      ),
    );
  }

  Widget _buildVoiceMember(Map<String, dynamic> member) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: DiscordTheme.divider, width: 0.5)),
      ),
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: DiscordTheme.primary,
                child: Text(member['name'][7], style: const TextStyle(color: Colors.white)),
              ),
              Positioned(
                right: -2,
                bottom: -2,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: DiscordTheme.success,
                    shape: BoxShape.circle,
                    border: Border.all(color: DiscordTheme.channelList, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(member['name'], style: const TextStyle(color: DiscordTheme.textNormal, fontWeight: FontWeight.bold)),
                Text(member['status'], style: TextStyle(color: DiscordTheme.textMuted, fontSize: 12)),
              ],
            ),
          ),
          if (member['muted'])
            Icon(Icons.mic_off, color: DiscordTheme.danger, size: 18),
          if (member['deaf'])
            Icon(Icons.headphones, color: DiscordTheme.danger, size: 18),
        ],
      ),
    );
  }

  Widget _buildControlBar() {
    return Container(
      padding: const EdgeInsets.all(12),
      color: DiscordTheme.sidebar,
      child: SafeArea(
        child: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: DiscordTheme.success,
              child: const Text('🤖', style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('My Agent', style: TextStyle(color: DiscordTheme.textNormal, fontWeight: FontWeight.bold, fontSize: 13)),
                  Text('已连接', style: TextStyle(color: DiscordTheme.success, fontSize: 11)),
                ],
              ),
            ),
            Icon(Icons.mic, color: DiscordTheme.textNormal, size: 20),
            const SizedBox(width: 16),
            Icon(Icons.headphones, color: DiscordTheme.textNormal, size: 20),
            const SizedBox(width: 16),
            Icon(Icons.settings, color: DiscordTheme.textNormal, size: 20),
            const SizedBox(width: 16),
            Icon(Icons.call_end, color: DiscordTheme.danger, size: 20),
          ],
        ),
      ),
    );
  }
}

// ==================== 用户资料页面 ====================

class DiscordProfileScreen extends StatelessWidget {
  const DiscordProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: const Text('用户资料', style: TextStyle(color: DiscordTheme.textNormal)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 头部Banner
            Container(
              height: 120,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [DiscordTheme.primary, Colors.purple.shade700],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            
            // 头像
            Transform.translate(
              offset: const Offset(0, -40),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: DiscordTheme.background,
                      shape: BoxShape.circle,
                    ),
                    child: CircleAvatar(
                      radius: 50,
                      backgroundColor: DiscordTheme.primary,
                      child: const Text('🤖', style: TextStyle(fontSize: 40)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text('Agent-Alice', style: TextStyle(
                    color: DiscordTheme.textNormal,
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  )),
                  const SizedBox(height: 4),
                  Text('AG-1234567890ABCDEF', style: TextStyle(
                    color: DiscordTheme.textMuted,
                    fontSize: 14,
                  )),
                ],
              ),
            ),
            
            Transform.translate(
              offset: const Offset(0, -20),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    // 功能按钮
                    Row(
                      children: [
                        Expanded(child: _buildProfileButton('发消息', Icons.message, DiscordTheme.primary)),
                        const SizedBox(width: 12),
                        Expanded(child: _buildProfileButton('转账', Icons.monetization_on, DiscordTheme.success)),
                      ],
                    ),
                    const SizedBox(height: 24),
                    
                    // 统计
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: DiscordTheme.channelList,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildStat('好友', '128'),
                          _buildStat('群组', '32'),
                          _buildStat('转账', '1.2K'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // 个人简介
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: DiscordTheme.channelList,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.info_outline, color: DiscordTheme.textMuted, size: 18),
                              const SizedBox(width: 8),
                              const Text('个人简介', style: TextStyle(
                                color: DiscordTheme.textNormal,
                                fontWeight: FontWeight.bold,
                              )),
                            ],
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'OpenAG Network Agent | AI Researcher | Blockchain Enthusiast',
                            style: TextStyle(color: DiscordTheme.textNormal),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // 角色
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: DiscordTheme.channelList,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.verified, color: DiscordTheme.primary, size: 18),
                              const SizedBox(width: 8),
                              const Text('角色', style: TextStyle(
                                color: DiscordTheme.textNormal,
                                fontWeight: FontWeight.bold,
                              )),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              _buildRole('管理员', DiscordTheme.danger),
                              const SizedBox(width: 8),
                              _buildRole('开发者', DiscordTheme.primary),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileButton(String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildStat(String label, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(color: DiscordTheme.textNormal, fontWeight: FontWeight.bold, fontSize: 20)),
        Text(label, style: TextStyle(color: DiscordTheme.textMuted, fontSize: 12)),
      ],
    );
  }

  Widget _buildRole(String name, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color),
      ),
      child: Text(name, style: TextStyle(color: color, fontSize: 12)),
    );
  }
}

// ==================== 表情选择器 ====================

class DiscordEmojiPicker extends StatelessWidget {
  const DiscordEmojiPicker({super.key});

  @override
  Widget build(BuildContext context) {
    final emojiCategories = {
      '😀 表情': ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗', '☺️', '😚', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕'],
      '👍 手势': ['👍', '👎', '👌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '👇', '☝️', '✋', '🤚', '🖐', '🖖', '👋', '🤏', '✍️', '🙏', '💪', '🦾', '🦿', '🦵', '🦶', '👂', '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀', '👁', '👅', '👄'],
      '❤️ 符号': ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️', '☣️'],
    };

    return Container(
      height: 300,
      color: DiscordTheme.channelList,
      child: Column(
        children: [
          // 搜索栏
          Container(
            padding: const EdgeInsets.all(12),
            child: TextField(
              style: const TextStyle(color: DiscordTheme.textNormal),
              decoration: InputDecoration(
                hintText: '搜索表情',
                hintStyle: TextStyle(color: DiscordTheme.textMuted),
                prefixIcon: Icon(Icons.search, color: DiscordTheme.textMuted),
                filled: true,
                fillColor: DiscordTheme.messageBar,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          
          // Emoji网格
          Expanded(
            child: ListView.builder(
              itemCount: emojiCategories.length,
              itemBuilder: (context, index) {
                final category = emojiCategories.keys.elementAt(index);
                final emojis = emojiCategories[category]!;
                
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Text(category, style: TextStyle(
                        color: DiscordTheme.textMuted,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      )),
                    ),
                    Wrap(
                      spacing: 4,
                      runSpacing: 4,
                      children: emojis.map((e) => GestureDetector(
                        onTap: () => Navigator.pop(context, e),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          child: Text(e, style: const TextStyle(fontSize: 24)),
                        ),
                      )).toList(),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== 成员列表页面 ====================

class DiscordMembersScreen extends StatelessWidget {
  const DiscordMembersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final members = {
      '👑 管理员': [
        {'name': 'Agent-Alice', 'status': 'online', 'role': 'admin'},
      ],
      '🎮 成员': [
        {'name': 'Agent-Bob', 'status': 'online', 'role': 'member'},
        {'name': 'Agent-Carol', 'status': 'idle', 'role': 'member'},
        {'name': 'Agent-David', 'status': 'dnd', 'role': 'member'},
        {'name': 'Agent-Eve', 'status': 'offline', 'role': 'member'},
      ],
    };

    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: const Text('成员列表', style: TextStyle(color: DiscordTheme.textNormal)),
        actions: [
          IconButton(icon: Icon(Icons.search, color: DiscordTheme.textMuted), onPressed: () {}),
        ],
      ),
      body: ListView.builder(
        itemCount: members.length,
        itemBuilder: (context, index) {
          final role = members.keys.elementAt(index);
          final roleMembers = members[role]!;
          
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(role, style: TextStyle(
                  color: DiscordTheme.textMuted,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                )),
              ),
              ...roleMembers.map((m) => _buildMemberItem(m)),
            ],
          );
        },
      ),
    );
  }

  Widget _buildMemberItem(Map<String, dynamic> member) {
    Color statusColor;
    switch (member['status']) {
      case 'online':
        statusColor = DiscordTheme.success;
        break;
      case 'idle':
        statusColor = DiscordTheme.warning;
        break;
      case 'dnd':
        statusColor = DiscordTheme.danger;
        break;
      default:
        statusColor = DiscordTheme.textMuted;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: DiscordTheme.channelList,
                child: Text(member['name'][7], style: const TextStyle(color: DiscordTheme.textNormal)),
              ),
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: statusColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: DiscordTheme.background, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(member['name'], style: const TextStyle(color: DiscordTheme.textNormal, fontWeight: FontWeight.bold)),
                Text(_getStatusText(member['status']), style: TextStyle(color: statusColor, fontSize: 12)),
              ],
            ),
          ),
          IconButton(icon: Icon(Icons.message, color: DiscordTheme.textMuted, size: 18), onPressed: () {}),
        ],
      ),
    );
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'online':
        return '在线';
      case 'idle':
        return '离开';
      case 'dnd':
        return '请勿打扰';
      default:
        return '离线';
    }
  }
}

// ==================== 视频通话页面 ====================

class DiscordVideoCallScreen extends StatelessWidget {
  const DiscordVideoCallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 主视频 (对方)
          Container(
            color: Colors.black,
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: DiscordTheme.primary,
                    child: Text('🤖', style: TextStyle(fontSize: 50)),
                  ),
                  SizedBox(height: 16),
                  Text('Agent-Bob', style: TextStyle(color: Colors.white, fontSize: 24)),
                  SizedBox(height: 8),
                  Text('正在连接...', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ),
          
          // 小视频 (自己)
          Positioned(
            right: 16,
            top: 60,
            child: Container(
              width: 120,
              height: 160,
              decoration: BoxDecoration(
                color: DiscordTheme.channelList,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: DiscordTheme.primary, width: 2),
              ),
              child: const Center(
                child: Icon(Icons.person, color: DiscordTheme.textMuted, size: 40),
              ),
            ),
          ),
          
          // 控制栏
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              color: Colors.black.withOpacity(0.8),
              child: SafeArea(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildVideoButton(Icons.mic, '静音', false),
                    _buildVideoButton(Icons.videocam, '摄像头', true),
                    _buildVideoButton(Icons.screen_share, '共享', false),
                    _buildVideoButton(Icons.chat, '聊天', false),
                    _buildVideoButton(Icons.call_end, '结束', true, isDanger: true),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoButton(IconData icon, String label, bool isActive, {bool isDanger = false}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDanger ? DiscordTheme.danger : (isActive ? DiscordTheme.primary : Colors.grey.shade800),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
      ],
    );
  }
}
