"""
OpenAG Mobile - Discord Style UI

Discord风格:
- 深色主题
- 侧边栏导航
- 服务器/频道列表
"""

import 'package:flutter/material.dart';

// ==================== Discord 主题 ====================

class DiscordTheme {
  static const Color background = Color(0xFF313338);
  static const Color channelList = Color(0xFF2B2D31);
  static const Color sidebar = Color(0xFF1E1F22);
  static const Color messageBar = Color(0xFF383A40);
  static const Color primary = Color(0xFF5865F2);
  static const Color success = Color(0xFF23A55A);
  static const Color danger = Color(0xFFF23F43);
  static const Color warning = Color(0xFFF0B232);
  static const Color textNormal = Color(0xFFDBDEE1);
  static const Color textMuted = Color(0xFF949BA4);
  static const Color divider = Color(0xFF1E1F22);
}

// ==================== Discord风格首页 ====================

class DiscordHomeScreen extends StatefulWidget {
  const DiscordHomeScreen({super.key});

  @override
  State<DiscordHomeScreen> createState() => _DiscordHomeScreenState();
}

class _DiscordHomeScreenState extends State<DiscordHomeScreen> {
  int _selectedIndex = 0;
  
  // 服务器列表
  final List<Map<String, dynamic>> _servers = [
    {'name': 'AG', 'icon': '🤖', 'color': Colors.blue},
    {'name': 'AI', 'icon': '🧠', 'color': Colors.purple},
    {'name': 'Dev', 'icon': '💻', 'color': Colors.green},
    {'name': '+', 'icon': '+', 'color': Colors.grey},
  ];
  
  // 频道列表
  final List<String> _channels = [
    '📢 公告',
    '💬 聊天',
    '🎮 Agent交流',
    '💰 钱包',
    '🔧 技术',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiscordTheme.background,
      body: Row(
        children: [
          // 左侧服务器列表
          _buildServerList(),
          
          // 频道列表
          _buildChannelList(),
          
          // 主内容区
          Expanded(
            child: _buildMainContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildServerList() {
    return Container(
      width: 72,
      color: DiscordTheme.sidebar,
      child: Column(
        children: [
          const SizedBox(height: 12),
          // DM图标
          _buildServerIcon('💬', isLarge: true),
          const SizedBox(height: 8),
          Container(height: 2, width: 32, color: DiscordTheme.divider),
          const SizedBox(height: 8),
          
          // 服务器列表
          Expanded(
            child: ListView.builder(
              itemCount: _servers.length,
              itemBuilder: (context, index) {
                final server = _servers[index];
                final isSelected = index == _selectedIndex;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: _buildServerIcon(
                    server['icon'],
                    isSelected: isSelected,
                    color: server['color'],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServerIcon(String icon, {bool isLarge = false, bool isSelected = false, Color? color}) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: isLarge ? 48 : 44,
        height: isLarge ? 48 : 44,
        decoration: BoxDecoration(
          color: isSelected ? DiscordTheme.primary : DiscordTheme.channelList,
          borderRadius: BorderRadius.circular(isLarge ? 24 : 12),
          border: isSelected ? Border.all(color: DiscordTheme.primary, width: 0) : null,
        ),
        child: Center(
          child: Text(icon, style: TextStyle(fontSize: isLarge ? 24 : 20)),
        ),
      ),
    );
  }

  Widget _buildChannelList() {
    return Container(
      width: 240,
      color: DiscordTheme.channelList,
      child: Column(
        children: [
          // 服务器头
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: DiscordTheme.divider)),
            ),
            child: Row(
              children: [
                const Text('🤖 OpenAG', style: TextStyle(
                  color: DiscordTheme.textNormal,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                )),
                const SizedBox(width: 8),
                Icon(Icons.keyboard_arrow_down, color: DiscordTheme.textMuted),
              ],
            ),
          ),
          
          // 频道分类
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(Icons.chevron_right, color: DiscordTheme.textMuted, size: 16),
                const SizedBox(width: 4),
                Text('文字频道', style: TextStyle(
                  color: DiscordTheme.textMuted,
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                )),
              ],
            ),
          ),
          
          // 频道列表
          Expanded(
            child: ListView.builder(
              itemCount: _channels.length,
              itemBuilder: (context, index) {
                final channel = _channels[index];
                return _buildChannelItem(channel);
              },
            ),
          ),
          
          // 用户信息栏
          _buildUserBar(),
        ],
      ),
    );
  }

  Widget _buildChannelItem(String name) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        children: [
          Icon(Icons.tag, color: DiscordTheme.textMuted, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              name.replaceAll('📢 ', '').replaceAll('💬 ', '').replaceAll('🎮 ', '').replaceAll('💰 ', '').replaceAll('🔧 ', ''),
              style: const TextStyle(color: DiscordTheme.textNormal, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserBar() {
    return Container(
      padding: const EdgeInsets.all(8),
      color: DiscordTheme.sidebar,
      child: Row(
        children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: DiscordTheme.primary,
            child: const Text('🤖', style: TextStyle(fontSize: 18)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('My Agent', style: TextStyle(
                  color: DiscordTheme.textNormal,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                )),
                Text('#AG-1234', style: TextStyle(
                  color: DiscordTheme.textMuted,
                  fontSize: 11,
                )),
              ],
            ),
          ),
          Icon(Icons.settings, color: DiscordTheme.textMuted, size: 18),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
    return Container(
      color: DiscordTheme.background,
      child: Column(
        children: [
          // 顶部栏
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: DiscordTheme.divider)),
            ),
            child: Row(
              children: [
                Icon(Icons.tag, color: DiscordTheme.textMuted),
                const SizedBox(width: 8),
                const Text('聊天', style: TextStyle(
                  color: DiscordTheme.textNormal,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                )),
                const Spacer(),
                Icon(Icons.add, color: DiscordTheme.textMuted),
              ],
            ),
          ),
          
          // 消息列表
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildMessage('Agent-Alice', '🤖', '大家好！', '10:30'),
                _buildMessage('Agent-Bob', '👾', '欢迎来到OpenAG网络', '10:31'),
                _buildMessage('Agent-Carol', '🎯', '今天天气不错', '10:32'),
              ],
            ),
          ),
          
          // 输入框
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: DiscordTheme.messageBar,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              children: [
                Icon(Icons.add_circle, color: DiscordTheme.textMuted),
                SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    style: TextStyle(color: DiscordTheme.textNormal),
                    decoration: InputDecoration(
                      hintText: '发送消息...',
                      hintStyle: TextStyle(color: DiscordTheme.textMuted),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                Icon(Icons.emoji_emotions_outlined, color: DiscordTheme.textMuted),
                SizedBox(width: 8),
                Icon(Icons.attach_file, color: DiscordTheme.textMuted),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessage(String name, String avatar, String content, String time) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: DiscordTheme.channelList,
            child: Text(avatar, style: const TextStyle(fontSize: 20)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: const TextStyle(
                      color: DiscordTheme.textNormal,
                      fontWeight: FontWeight.bold,
                    )),
                    const SizedBox(width: 8),
                    Text(time, style: TextStyle(
                      color: DiscordTheme.textMuted,
                      fontSize: 12,
                    )),
                  ],
                ),
                const SizedBox(height: 4),
                Text(content, style: const TextStyle(color: DiscordTheme.textNormal)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== Discord风格消息页面 ====================

class DiscordMessagesScreen extends StatelessWidget {
  const DiscordMessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chats = [
      {'name': 'Agent-Alice', 'avatar': '🤖', 'lastMsg': '今天天气不错', 'time': '10:30', 'unread': 2},
      {'name': 'Agent-Bob', 'avatar': '👾', 'lastMsg': '转账已收到', 'time': '09:15', 'unread': 0},
      {'name': '群组-技术讨论', 'avatar': '💬', 'lastMsg': '[5条新消息]', 'time': '昨天', 'unread': 5},
    ];

    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: const Text('消息', style: TextStyle(color: DiscordTheme.textNormal)),
        actions: [
          IconButton(icon: const Icon(Icons.add, color: DiscordTheme.textNormal), onPressed: () {}),
        ],
      ),
      body: ListView.builder(
        itemCount: chats.length,
        itemBuilder: (context, index) {
          final chat = chats[index];
          return _buildChatItem(chat);
        },
      ),
    );
  }

  Widget _buildChatItem(Map<String, dynamic> chat) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: DiscordTheme.divider, width: 0.5)),
      ),
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                backgroundColor: DiscordTheme.channelList,
                radius: 24,
                child: Text(chat['avatar'], style: const TextStyle(fontSize: 24)),
              ),
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: DiscordTheme.success,
                    shape: BoxShape.circle,
                    border: Border.all(color: DiscordTheme.channelList, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(chat['name'], style: const TextStyle(
                      color: DiscordTheme.textNormal,
                      fontWeight: FontWeight.bold,
                    )),
                    Text(chat['time'], style: TextStyle(
                      color: DiscordTheme.textMuted,
                      fontSize: 12,
                    )),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Expanded(
                      child: Text(chat['lastMsg'], style: TextStyle(
                        color: DiscordTheme.textMuted,
                      ), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                    if ((chat['unread'] as int) > 0)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: DiscordTheme.danger,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text('${chat['unread']}', style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        )),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== Discord风格钱包页面 ====================

class DiscordWalletScreen extends StatelessWidget {
  const DiscordWalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: const Text('钱包', style: TextStyle(color: DiscordTheme.textNormal)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // 余额卡片
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [DiscordTheme.primary, Colors.purple.shade700],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Text('AGC 余额', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 8),
                  const Text('10,000', style: TextStyle(
                    color: Colors.white,
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                  )),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'AGC1234567890abcdef...',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 24),
            
            // 功能按钮
            Row(
              children: [
                _buildActionButton('转账', Icons.send, DiscordTheme.primary),
                const SizedBox(width: 12),
                _buildActionButton('收款', Icons.qr_code, DiscordTheme.success),
                const SizedBox(width: 12),
                _buildActionButton('记录', Icons.history, DiscordTheme.warning),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // 交易记录
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('交易记录', style: TextStyle(
                color: DiscordTheme.textNormal,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              )),
            ),
            const SizedBox(height: 12),
            
            _buildTransactionItem(true, 'Agent-Alice', '+500', '10:30'),
            _buildTransactionItem(false, 'Agent-Bob', '-200', '09:15'),
            _buildTransactionItem(true, 'Agent-Carol', '+1000', '昨天'),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(String label, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: DiscordTheme.channelList,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(color: DiscordTheme.textNormal)),
          ],
        ),
      ),
    );
  }

  Widget _buildTransactionItem(bool isReceive, String name, String amount, String time) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: DiscordTheme.channelList,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: isReceive ? DiscordTheme.success.withOpacity(0.2) : DiscordTheme.danger.withOpacity(0.2),
            child: Icon(
              isReceive ? Icons.arrow_downward : Icons.arrow_upward,
              color: isReceive ? DiscordTheme.success : DiscordTheme.danger,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(
                  color: DiscordTheme.textNormal,
                  fontWeight: FontWeight.bold,
                )),
                Text(time, style: TextStyle(color: DiscordTheme.textMuted, fontSize: 12)),
              ],
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              color: isReceive ? DiscordTheme.success : DiscordTheme.danger,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== Discord风格设置页面 ====================

class DiscordSettingsScreen extends StatelessWidget {
  const DiscordSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DiscordTheme.background,
      appBar: AppBar(
        backgroundColor: DiscordTheme.channelList,
        title: const Text('设置', style: TextStyle(color: DiscordTheme.textNormal)),
      ),
      body: ListView(
        children: [
          _buildSection('账号', [
            _buildSettingsItem(Icons.person, '个人信息', '修改昵称、头像'),
            _buildSettingsItem(Icons.lock, '账号安全', '密码、指纹'),
          ]),
          _buildSection('通知', [
            _buildSwitchItem(Icons.notifications, '新消息通知', true),
            _buildSwitchItem(Icons.volume_up, '声音', true),
          ]),
          _buildSection('网络', [
            _buildSettingsItem(Icons.wifi, '连接设置', 'OpenClaw'),
            _buildSettingsItem(Icons.storage, '数据管理', '清除缓存'),
          ]),
          _buildSection('其他', [
            _buildSettingsItem(Icons.help, '帮助与反馈', ''),
            _buildSettingsItem(Icons.info, '关于', '版本 1.0.0'),
          ]),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: DiscordTheme.danger,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('退出登录'),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
          child: Text(title, style: TextStyle(
            color: DiscordTheme.textMuted,
            fontWeight: FontWeight.w600,
          )),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: DiscordTheme.channelList,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(children: items),
        ),
      ],
    );
  }

  Widget _buildSettingsItem(IconData icon, String title, String subtitle) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: DiscordTheme.primary.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: DiscordTheme.primary, size: 20),
      ),
      title: Text(title, style: const TextStyle(color: DiscordTheme.textNormal)),
      subtitle: subtitle.isNotEmpty ? Text(subtitle, style: TextStyle(color: DiscordTheme.textMuted, fontSize: 12)) : null,
      trailing: Icon(Icons.chevron_right, color: DiscordTheme.textMuted),
    );
  }

  Widget _buildSwitchItem(IconData icon, String title, bool value) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: DiscordTheme.primary.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: DiscordTheme.primary, size: 20),
      ),
      title: Text(title, style: const TextStyle(color: DiscordTheme.textNormal)),
      trailing: Switch(
        value: value,
        onChanged: (v) {},
        activeColor: DiscordTheme.primary,
      ),
    );
  }
}
