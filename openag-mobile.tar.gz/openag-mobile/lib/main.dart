"""
OpenAG Mobile - Discord Style Main App

Discord风格主程序
"""

import 'package:flutter/material.dart';

import 'ui/discord_style.dart';

void main() {
  runApp(const OpenAGApp());
}

class OpenAGApp extends StatelessWidget {
  const OpenAGApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OpenAG',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF313338),
        primaryColor: const Color(0xFF5865F2),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF5865F2),
          secondary: Color(0xFF23A55A),
          error: Color(0xFFF23F43),
          surface: Color(0xFF2B2D31),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF2B2D31),
          foregroundColor: Color(0xFFDBDEE1),
          elevation: 0,
        ),
      ),
      home: const DiscordMainScreen(),
    );
  }
}

class DiscordMainScreen extends StatefulWidget {
  const DiscordMainScreen({super.key});

  @override
  State<DiscordMainScreen> createState() => _DiscordMainScreenState();
}

class _DiscordMainScreenState extends State<DiscordMainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // 左侧导航栏
          _buildNavigationRail(),
          
          // 主内容
          Expanded(
            child: IndexedStack(
              index: _currentIndex,
              children: const [
                DiscordHomeScreen(),
                DiscordMessagesScreen(),
                DiscordWalletScreen(),
                DiscordSettingsScreen(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationRail() {
    final navItems = [
      {'icon': Icons.home, 'label': '首页'},
      {'icon': Icons.message, 'label': '消息'},
      {'icon': Icons.wallet, 'label': '钱包'},
      {'icon': Icons.settings, 'label': '设置'},
    ];

    return Container(
      width: 72,
      color: const Color(0xFF1E1F22),
      child: Column(
        children: [
          const SizedBox(height: 12),
          
          // Logo
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF5865F2),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Center(
              child: Text('🤖', style: TextStyle(fontSize: 24)),
            ),
          ),
          
          const SizedBox(height: 8),
          Container(height: 2, width: 32, color: const Color(0xFF383A40)),
          
          const SizedBox(height: 8),
          
          // 导航项
          Expanded(
            child: ListView.builder(
              itemCount: navItems.length,
              itemBuilder: (context, index) {
                final item = navItems[index];
                final isSelected = index == _currentIndex;
                
                return GestureDetector(
                  onTap: () => setState(() => _currentIndex = index),
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isSelected ? const Color(0xFF5865F2) : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          item['icon'] as IconData,
                          color: isSelected ? Colors.white : const Color(0xFF949BA4),
                          size: 24,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item['label'] as String,
                          style: TextStyle(
                            color: isSelected ? Colors.white : const Color(0xFF949BA4),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          // 用户头像
          Container(
            margin: const EdgeInsets.all(8),
            child: const CircleAvatar(
              radius: 20,
              backgroundColor: Color(0xFF23A55A),
              child: Text('🤖', style: TextStyle(fontSize: 18)),
            ),
          ),
        ],
      ),
    );
  }
}
