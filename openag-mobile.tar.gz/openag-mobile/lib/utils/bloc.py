"""
BLoC - 状态管理

使用BLoC模式管理状态
"""

import asyncio
from typing import Dict, Any, Optional
from dataclasses import dataclass, field


# ==================== Base BLoC ====================

class Bloc:
    """基础BLoC"""
    
    def __init__(self):
        self._state: Any = None
        self._stream_controller: asyncio.Queue = None
    
    @property
    def state(self) -> Any:
        return self._state
    
    async def emit(self, state: Any) -> None:
        """发射新状态"""
        self._state = state


# ==================== Auth BLoC ====================

@dataclass
class AuthState:
    """认证状态"""
    is_authenticated: bool = False
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    loading: bool = False
    error: Optional[str] = None


class AuthBloc(Bloc):
    """认证BLoC"""
    
    def __init__(self):
        super().__init__()
        self._state = AuthState()
    
    async def login(self, username: str, password: str) -> bool:
        """登录"""
        self.emit(AuthState(loading=True))
        
        try:
            # 模拟登录
            await asyncio.sleep(1)
            
            agent_id = f"AG-{hash(username) % 1000000000000000:016X}"
            
            self.emit(AuthState(
                is_authenticated=True,
                user_id=username,
                agent_id=agent_id
            ))
            return True
            
        except Exception as e:
            self.emit(AuthState(error=str(e)))
            return False
    
    async def logout(self) -> None:
        """登出"""
        self.emit(AuthState())
    
    async def register(self, username: str, password: str, invite_code: str = None) -> bool:
        """注册"""
        self.emit(AuthState(loading=True))
        
        try:
            await asyncio.sleep(1)
            
            agent_id = f"AG-{hash(username) % 1000000000000000:016X}"
            
            self.emit(AuthState(
                is_authenticated=True,
                user_id=username,
                agent_id=agent_id
            ))
            return True
            
        except Exception as e:
            self.emit(AuthState(error=str(e)))
            return False


# ==================== Message BLoC ====================

@dataclass
class MessageState:
    """消息状态"""
    chats: list = field(default_factory=list)
    current_chat: Optional[str] = None
    messages: list = field(default_factory=list)
    loading: bool = False
    error: Optional[str] = None


class MessageBloc(Bloc):
    """消息BLoC"""
    
    def __init__(self):
        super().__init__()
        self._state = MessageState()
    
    async def load_chats(self) -> None:
        """加载聊天列表"""
        self.emit(MessageState(loading=True))
        
        try:
            await asyncio.sleep(0.5)
            
            chats = [
                {"chat_id": "1", "name": "Agent-Alice", "last_msg": "你好", "time": "10:30"},
                {"chat_id": "2", "name": "Agent-Bob", "last_msg": "转账收到", "time": "09:15"},
            ]
            
            self.emit(MessageState(chats=chats))
            
        except Exception as e:
            self.emit(MessageState(error=str(e)))
    
    async def load_messages(self, chat_id: str) -> None:
        """加载消息"""
        self.emit(MessageState(loading=True, current_chat=chat_id))
        
        try:
            await asyncio.sleep(0.3)
            
            messages = [
                {"id": "1", "type": "receive", "content": "你好", "time": "10:00"},
                {"id": "2", "type": "send", "content": "你好有什么事?", "time": "10:01"},
            ]
            
            self.emit(MessageState(current_chat=chat_id, messages=messages))
            
        except Exception as e:
            self.emit(MessageState(error=str(e)))
    
    async def send_message(self, content: str) -> bool:
        """发送消息"""
        if not self._state.current_chat:
            return False
        
        try:
            new_message = {
                "id": str(len(self._state.messages) + 1),
                "type": "send",
                "content": content,
                "time": "现在"
            }
            
            messages = self._state.messages + [new_message]
            self.emit(MessageState(
                current_chat=self._state.current_chat,
                messages=messages
            ))
            
            return True
            
        except Exception as e:
            return False


# ==================== Wallet BLoC ====================

@dataclass
class WalletState:
    """钱包状态"""
    balance: int = 0
    address: str = ""
    transactions: list = field(default_factory=list)
    loading: bool = False
    error: Optional[str] = None


class WalletBloc(Bloc):
    """钱包BLoC"""
    
    def __init__(self):
        super().__init__()
        self._state = WalletState()
    
    async def load_wallet(self, agent_id: str) -> None:
        """加载钱包"""
        self.emit(WalletState(loading=True))
        
        try:
            await asyncio.sleep(0.5)
            
            address = f"AGC{hash(agent_id) % 100000000000000000000:040x}"
            
            transactions = [
                {"id": "1", "type": "receive", "amount": 1000, "from": "Agent-Alice", "time": "10:00"},
                {"id": "2", "type": "send", "amount": 500, "to": "Agent-Bob", "time": "09:00"},
            ]
            
            self.emit(WalletState(
                balance=10000,
                address=address,
                transactions=transactions
            ))
            
        except Exception as e:
            self.emit(WalletState(error=str(e)))
    
    async def transfer(self, to_address: str, amount: int) -> bool:
        """转账"""
        if amount > self._state.balance:
            self.emit(WalletState(
                balance=self._state.balance,
                address=self._state.address,
                transactions=self._state.transactions,
                error="余额不足"
            ))
            return False
        
        self.emit(WalletState(loading=True))
        
        try:
            await asyncio.sleep(1)
            
            new_tx = {
                "id": str(len(self._state.transactions) + 1),
                "type": "send",
                "amount": amount,
                "to": to_address,
                "time": "现在"
            }
            
            self.emit(WalletState(
                balance=self._state.balance - amount,
                address=self._state.address,
                transactions=[new_tx] + self._state.transactions
            ))
            
            return True
            
        except Exception as e:
            self.emit(WalletState(error=str(e)))
            return False


# ==================== OpenClaw BLoC ====================

@dataclass
class OpenClawState:
    """OpenClaw状态"""
    connected: bool = False
    host: str = ""
    port: int = 8080
    agents: list = field(default_factory=list)
    loading: bool = False
    error: Optional[str] = None


class OpenClawBloc(Bloc):
    """OpenClaw BLoC"""
    
    def __init__(self):
        super().__init__()
        self._state = OpenClawState()
    
    async def connect(self, host: str, port: int) -> bool:
        """连接"""
        self.emit(OpenClawState(loading=True, host=host, port=port))
        
        try:
            await asyncio.sleep(1)
            
            agents = [
                {"id": "agent-1", "name": "Agent-1", "status": "running"},
                {"id": "agent-2", "name": "Agent-2", "status": "idle"},
            ]
            
            self.emit(OpenClawState(
                connected=True,
                host=host,
                port=port,
                agents=agents
            ))
            
            return True
            
        except Exception as e:
            self.emit(OpenClawState(error=str(e)))
            return False
    
    async def disconnect(self) -> None:
        """断开"""
        self.emit(OpenClawState())
    
    async def start_agent(self, agent_id: str) -> bool:
        """启动Agent"""
        if not self._state.connected:
            return False
        
        try:
            for agent in self._state.agents:
                if agent["id"] == agent_id:
                    agent["status"] = "running"
            
            self.emit(self._state)
            return True
            
        except Exception as e:
            return False
    
    async def stop_agent(self, agent_id: str) -> bool:
        """停止Agent"""
        if not self._state.connected:
            return False
        
        try:
            for agent in self._state.agents:
                if agent["id"] == agent_id:
                    agent["status"] = "stopped"
            
            self.emit(self._state)
            return True
            
        except Exception as e:
            return False


# ==================== Dependency Injection ====================

class ServiceLocator:
    """服务定位器"""
    
    _services: Dict[str, Any] = {}
    
    @classmethod
    def register(cls, name: str, service: Any) -> None:
        cls._services[name] = service
    
    @classmethod
    def get(cls, name: str) -> Any:
        return cls._services.get(name)
    
    @classmethod
    def initialize(cls) -> None:
        """初始化服务"""
        cls.register("auth", AuthBloc())
        cls.register("message", MessageBloc())
        cls.register("wallet", WalletBloc())
        cls.register("openclaw", OpenClawBloc())
    
    @classmethod
    def auth(cls) -> AuthBloc:
        return cls.get("auth")
    
    @classmethod
    def message(cls) -> MessageBloc:
        return cls.get("message")
    
    @classmethod
    def wallet(cls) -> WalletBloc:
        return cls.get("wallet")
    
    @classmethod
    def openclaw(cls) -> OpenClawBloc:
        return cls.get("openclaw")


# 初始化
ServiceLocator.initialize()
