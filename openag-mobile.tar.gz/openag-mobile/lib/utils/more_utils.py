"""
More Utils - 更多工具函数

包含:
- 主题管理
- 动画
- 媒体处理
- 权限管理
"""

import time
import uuid
import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field


# ==================== Theme Manager ====================

class ThemeMode(str, Enum):
    LIGHT = "light"
    DARK = "dark"
    SYSTEM = "system"


class Theme:
    """主题"""
    
    # Discord主题
    DISCORD_DARK = {
        "background": "#313338",
        "channel_list": "#2B2D31",
        "sidebar": "#1E1F22",
        "message_bar": "#383A40",
        "primary": "#5865F2",
        "success": "#23A55A",
        "danger": "#F23F43",
        "warning": "#F0B232",
        "text_normal": "#DBDEE1",
        "text_muted": "#949BA4",
    }
    
    # 浅色主题
    LIGHT = {
        "background": "#FFFFFF",
        "channel_list": "#F2F3F5",
        "sidebar": "#F2F3F5",
        "message_bar": "#E3E5E8",
        "primary": "#5865F2",
        "success": "#23A55A",
        "danger": "#F23F43",
        "warning": "#F0B232",
        "text_normal": "#060607",
        "text_muted": "#4E5058",
    }


class ThemeManager:
    """主题管理器"""
    
    def __init__(self):
        self._current_theme = ThemeMode.DARK
        self._custom_themes: Dict[str, Dict] = {}
    
    def set_theme(self, mode: ThemeMode) -> None:
        self._current_theme = mode
    
    def get_theme(self) -> Dict:
        if self._current_theme == ThemeMode.DARK:
            return Theme.DISCORD_DARK
        elif self._current_theme == ThemeMode.LIGHT:
            return Theme.LIGHT
        else:
            # 系统主题
            return Theme.DISCORD_DARK
    
    def add_custom_theme(self, name: str, theme: Dict) -> None:
        self._custom_themes[name] = theme
    
    def get_theme_names(self) -> List[str]:
        return list(self._custom_themes.keys())


# ==================== Permission Manager ====================

class Permission(str, Enum):
    CAMERA = "camera"
    MICROPHONE = "microphone"
    STORAGE = "storage"
    LOCATION = "location"
    NOTIFICATION = "notification"
    CONTACTS = "contacts"


class PermissionStatus(str, Enum):
    GRANTED = "granted"
    DENIED = "denied"
    RESTRICTED = "restricted"
    NOT_DETERMINED = "not_determined"


class PermissionManager:
    """权限管理器"""
    
    def __init__(self):
        self._permissions: Dict[Permission, PermissionStatus] = {}
    
    async def request_permission(self, permission: Permission) -> PermissionStatus:
        """请求权限"""
        # 模拟请求
        await asyncio.sleep(0.5)
        
        # 默认授权
        status = PermissionStatus.GRANTED
        self._permissions[permission] = status
        return status
    
    def check_permission(self, permission: Permission) -> PermissionStatus:
        """检查权限"""
        return self._permissions.get(permission, PermissionStatus.NOT_DETERMINED)
    
    def is_granted(self, permission: Permission) -> bool:
        return self.check_permission(permission) == PermissionStatus.GRANTED
    
    async def request_multiple(self, permissions: List[Permission]) -> Dict[Permission, PermissionStatus]:
        """批量请求权限"""
        results = {}
        for p in permissions:
            results[p] = await self.request_permission(p)
        return results


# ==================== Media Manager ====================

class MediaType(str, Enum):
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    FILE = "file"


@dataclass
class MediaItem:
    """媒体项"""
    id: str
    media_type: MediaType
    url: str
    thumbnail: Optional[str] = None
    duration: Optional[int] = None
    size: Optional[int] = None
    name: str = ""
    created_at: float = field(default_factory=time.time)


class MediaManager:
    """媒体管理器"""
    
    def __init__(self):
        self._media_cache: Dict[str, MediaItem] = {}
    
    async def pick_image(self) -> Optional[MediaItem]:
        """选择图片"""
        # 模拟选择
        return MediaItem(
            id=str(uuid.uuid4()),
            media_type=MediaType.IMAGE,
            url="file:///placeholder.jpg",
            name="image.jpg"
        )
    
    async def pick_video(self) -> Optional[MediaItem]:
        """选择视频"""
        return MediaItem(
            id=str(uuid.uuid4()),
            media_type=MediaType.VIDEO,
            url="file:///placeholder.mp4",
            name="video.mp4",
            duration=120
        )
    
    async def pick_file(self) -> Optional[MediaItem]:
        """选择文件"""
        return MediaItem(
            id=str(uuid.uuid4()),
            media_type=MediaType.FILE,
            url="file:///placeholder.file",
            name="document.pdf"
        )
    
    async def compress_image(self, path: str, quality: int = 80) -> str:
        """压缩图片"""
        return path
    
    async def generate_thumbnail(self, path: str) -> str:
        """生成缩略图"""
        return path


# ==================== Audio Manager ====================

class AudioManager:
    """音频管理器"""
    
    def __init__(self):
        self._is_playing = False
        self._is_recording = False
        self._current_volume = 1.0
    
    async def play(self, path: str) -> None:
        """播放音频"""
        self._is_playing = True
        await asyncio.sleep(1)  # 模拟播放
        self._is_playing = False
    
    def pause(self) -> None:
        """暂停"""
        self._is_playing = False
    
    def stop(self) -> None:
        """停止"""
        self._is_playing = False
    
    async def start_recording(self) -> None:
        """开始录音"""
        self._is_recording = True
    
    async def stop_recording(self) -> Optional[str]:
        """停止录音"""
        self._is_recording = False
        return f"recording_{int(time.time())}.m4a"
    
    def set_volume(self, volume: float) -> None:
        """设置音量"""
        self._current_volume = max(0, min(1, volume))
    
    @property
    def is_playing(self) -> bool:
        return self._is_playing
    
    @property
    def is_recording(self) -> bool:
        return self._is_recording


# ==================== Video Manager ====================

class VideoManager:
    """视频管理器"""
    
    def __init__(self):
        self._is_playing = False
        self._is_recording = False
        self._camera_enabled = False
    
    async def start_camera(self) -> bool:
        """启动相机"""
        self._camera_enabled = True
        return True
    
    def stop_camera(self) -> None:
        """停止相机"""
        self._camera_enabled = False
    
    async def start_recording(self) -> None:
        """开始录制"""
        self._is_recording = True
    
    async def stop_recording(self) -> Optional[str]:
        """停止录制"""
        self._is_recording = False
        return f"video_{int(time.time())}.mp4"
    
    def switch_camera(self) -> None:
        """切换相机"""
        pass
    
    @property
    def is_recording(self) -> bool:
        return self._is_recording
    
    @property
    def is_camera_enabled(self) -> bool:
        return self._camera_enabled


# ==================== Logger ====================

class LogLevel(str, Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class Logger:
    """日志"""
    
    def __init__(self, tag: str):
        self._tag = tag
        self._logs: List[Dict] = []
    
    def _log(self, level: LogLevel, message: str) -> None:
        entry = {
            "time": time.time(),
            "level": level.value,
            "tag": self._tag,
            "message": message
        }
        self._logs.append(entry)
        print(f"[{level.value.upper()}] {self._tag}: {message}")
    
    def debug(self, message: str) -> None:
        self._log(LogLevel.DEBUG, message)
    
    def info(self, message: str) -> None:
        self._log(LogLevel.INFO, message)
    
    def warning(self, message: str) -> None:
        self._log(LogLevel.WARNING, message)
    
    def error(self, message: str) -> None:
        self._log(LogLevel.ERROR, message)
    
    def get_logs(self, level: LogLevel = None) -> List[Dict]:
        if level:
            return [l for l in self._logs if l["level"] == level.value]
        return self._logs
    
    def clear(self) -> None:
        self._logs.clear()


# ==================== Animations ====================

class AnimationUtils:
    """动画工具"""
    
    @staticmethod
    def fade_in(duration: int = 300) -> Dict:
        return {
            "opacity": {"begin": 0, "end": 1},
            "duration": duration
        }
    
    @staticmethod
    def fade_out(duration: int = 300) -> Dict:
        return {
            "opacity": {"begin": 1, "end": 0},
            "duration": duration
        }
    
    @staticmethod
    def slide_in(direction: str = "left", duration: int = 300) -> Dict:
        offsets = {
            "left": (-1, 0),
            "right": (1, 0),
            "up": (0, -1),
            "down": (0, 1)
        }
        offset = offsets.get(direction, (0, 0))
        return {
            "translate": {"begin": offset, "end": (0, 0)},
            "duration": duration
        }
    
    @staticmethod
    def scale(duration: int = 300) -> Dict:
        return {
            "scale": {"begin": 0.8, "end": 1.0},
            "duration": duration
        }


# ==================== Validators ====================

class Validators:
    """验证器"""
    
    @staticmethod
    def is_valid_agent_id(agent_id: str) -> bool:
        import re
        pattern = r'^AG-[A-F0-9]{16}$'
        return bool(re.match(pattern, agent_id.upper()))
    
    @staticmethod
    def is_valid_wallet(address: str) -> bool:
        import re
        pattern = r'^AGC[a-fA-F0-9]{40}$'
        return bool(re.match(pattern, address))
    
    @staticmethod
    def is_valid_amount(amount: int, min_val: int = 1, max_val: int = None) -> bool:
        if amount < min_val:
            return False
        if max_val and amount > max_val:
            return False
        return True
    
    @staticmethod
    def sanitize_input(text: str) -> str:
        # 移除危险字符
        return text.replace("<", "").replace(">", "").replace("&", "")


# ==================== Formatters ====================

class Formatters:
    """格式化"""
    
    @staticmethod
    def format_time(timestamp: float) -> str:
        from datetime import datetime
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%H:%M")
    
    @staticmethod
    def format_date(timestamp: float) -> str:
        from datetime import datetime
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d")
    
    @staticmethod
    def format_file_size(bytes_size: int) -> str:
        units = ["B", "KB", "MB", "GB", "TB"]
        size = float(bytes_size)
        unit_index = 0
        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1
        return f"{size:.1f} {units[unit_index]}"
    
    @staticmethod
    def format_duration(seconds: int) -> str:
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            minutes = seconds // 60
            secs = seconds % 60
            return f"{minutes}分{secs}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分"
    
    @staticmethod
    def format_number(num: int) -> str:
        if num < 1000:
            return str(num)
        elif num < 10000:
            return f"{num / 1000:.1f}K"
        elif num < 1000000:
            return f"{num / 1000:.0f}K"
        else:
            return f"{num / 1000000:.1f}M"


# ==================== Extensions ====================

class StringExtensions:
    """字符串扩展"""
    
    @staticmethod
    def truncate(text: str, max_length: int, suffix: str = "...") -> str:
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix
    
    @staticmethod
    def capitalize(text: str) -> str:
        return text.capitalize()
    
    @staticmethod
    def is_empty(text: str) -> bool:
        return not text or text.strip() == ""


class ListExtensions:
    """列表扩展"""
    
    @staticmethod
    def chunk(items: List, chunk_size: int) -> List[List]:
        return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]
    
    @staticmethod
    def unique(items: List) -> List:
        seen = set()
        result = []
        for item in items:
            if item not in seen:
                seen.add(item)
                result.append(item)
        return result


# 导出
theme_manager = ThemeManager()
permission_manager = PermissionManager()
media_manager = MediaManager()
audio_manager = AudioManager()
video_manager = VideoManager()
