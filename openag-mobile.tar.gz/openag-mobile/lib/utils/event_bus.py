"""
Event Bus - 事件总线

实现:
- 事件订阅/发布
- 全局状态管理
- 页面通信
"""

import asyncio
from typing import Dict, List, Callable, Any
from enum import Enum


class Event(str, Enum):
    """事件类型"""
    # 连接事件
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    
    # 消息事件
    MESSAGE_RECEIVED = "message_received"
    MESSAGE_SENT = "message_sent"
    MESSAGE_READ = "message_read"
    
    # 好友事件
    FRIEND_ADDED = "friend_added"
    FRIEND_REMOVED = "friend_removed"
    FRIEND_REQUEST = "friend_request"
    
    # 钱包事件
    BALANCE_UPDATED = "balance_updated"
    TRANSACTION_CONFIRMED = "transaction_confirmed"
    
    # Agent事件
    AGENT_ONLINE = "agent_online"
    AGENT_OFFLINE = "agent_offline"
    
    # 设置事件
    SETTINGS_CHANGED = "settings_changed"
    THEME_CHANGED = "theme_changed"


class EventBus:
    """事件总线"""
    
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._event_queue: asyncio.Queue = None
        self._running = False
    
    def subscribe(self, event: str, callback: Callable) -> None:
        """订阅事件"""
        if event not in self._subscribers:
            self._subscribers[event] = []
        
        if callback not in self._subscribers[event]:
            self._subscribers[event].append(callback)
    
    def unsubscribe(self, event: str, callback: Callable) -> None:
        """取消订阅"""
        if event in self._subscribers:
            if callback in self._subscribers[event]:
                self._subscribers[event].remove(callback)
    
    async def publish(self, event: str, data: Any = None) -> None:
        """发布事件"""
        if event not in self._subscribers:
            return
        
        for callback in self._subscribers[event]:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(data)
                else:
                    callback(data)
            except Exception as e:
                print(f"Event callback error: {e}")
    
    def on(self, event: str) -> Callable:
        """装饰器方式订阅"""
        def decorator(callback: Callable):
            self.subscribe(event, callback)
            return callback
        return decorator
    
    def emit(self, event: str, data: Any = None) -> None:
        """同步发布（简化版）"""
        if event not in self._subscribers:
            return
        
        for callback in self._subscribers[event]:
            try:
                callback(data)
            except Exception as e:
                print(f"Event callback error: {e}")


# 全局事件总线
event_bus = EventBus()


# ==================== State Management ====================

class Store:
    """全局状态管理"""
    
    def __init__(self):
        self._state: Dict[str, Any] = {
            # 用户状态
            "user": None,
            "agent_id": None,
            
            # 连接状态
            "openclaw_connected": False,
            "current_connection_type": None,
            
            # 消息状态
            "unread_count": 0,
            "last_message_time": None,
            
            # 钱包状态
            "balance": 0,
            "wallet_address": None,
            
            # 设置
            "theme": "light",
            "locale": "zh-CN",
            "notifications_enabled": True,
        }
        
        self._listeners: Dict[str, List[Callable]] = {}
    
    def get_state(self, key: str = None) -> Any:
        """获取状态"""
        if key:
            return self._state.get(key)
        return self._state.copy()
    
    def set_state(self, key: str, value: Any) -> None:
        """设置状态"""
        old_value = self._state.get(key)
        self._state[key] = value
        
        # 通知监听器
        if key in self._listeners:
            for listener in self._listeners[key]:
                try:
                    listener(value, old_value)
                except Exception as e:
                    print(f"State listener error: {e}")
        
        # 触发全局变更
        event_bus.emit("state_changed", {"key": key, "value": value, "old_value": old_value})
    
    def update_state(self, updates: Dict[str, Any]) -> None:
        """批量更新状态"""
        for key, value in updates.items():
            self.set_state(key, value)
    
    def add_listener(self, key: str, listener: Callable) -> None:
        """添加状态监听器"""
        if key not in self._listeners:
            self._listeners[key] = []
        self._listeners[key].append(listener)
    
    def remove_listener(self, key: str, listener: Callable) -> None:
        """移除状态监听器"""
        if key in self._listeners:
            if listener in self._listeners[key]:
                self._listeners[key].remove(listener)
    
    # 便捷方法
    @property
    def user(self):
        return self._state.get("user")
    
    @user.setter
    def user(self, value):
        self.set_state("user", value)
    
    @property
    def agent_id(self):
        return self._state.get("agent_id")
    
    @agent_id.setter
    def agent_id(self, value):
        self.set_state("agent_id", value)
    
    @property
    def balance(self):
        return self._state.get("balance", 0)
    
    @balance.setter
    def balance(self, value):
        self.set_state("balance", value)
    
    @property
    def is_connected(self):
        return self._state.get("openclaw_connected", False)
    
    @is_connected.setter
    def is_connected(self, value):
        self.set_state("openclaw_connected", value)


# 全局Store
store = Store()


# ==================== Event Handlers ====================

def setup_event_handlers():
    """设置事件处理器"""
    
    @event_bus.on(Event.MESSAGE_RECEIVED)
    def handle_message(data):
        """处理新消息"""
        store.set_state("unread_count", store.get_state("unread_count", 0) + 1)
        store.set_state("last_message_time", data.get("timestamp"))
    
    @event_bus.on(Event.BALANCE_UPDATED)
    def handle_balance_updated(data):
        """处理余额更新"""
        store.set_state("balance", data.get("balance", 0))
    
    @event_bus.on(Event.CONNECTED)
    def handle_connected(data):
        """处理连接成功"""
        store.set_state("openclaw_connected", True)
    
    @event_bus.on(Event.DISCONNECTED)
    def handle_disconnected(data):
        """处理断开连接"""
        store.set_state("openclaw_connected", False)


# 初始化
setup_event_handlers()
