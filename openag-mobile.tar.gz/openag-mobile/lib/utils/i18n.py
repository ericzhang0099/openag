"""
Internationalization - 国际化支持

支持多语言
"""

from enum import Enum
from typing import Dict


class Locale(str, Enum):
    """支持的语言"""
    ZH_CN = "zh-CN"
    ZH_TW = "zh-TW"
    EN_US = "en-US"
    JA_JP = "ja-JP"
    KO_KR = "ko-KR"


class I18n:
    """国际化"""
    
    _current_locale = Locale.ZH_CN
    _translations: Dict[Locale, Dict[str, str]] = {}
    
    @classmethod
    def set_locale(cls, locale: Locale) -> None:
        """设置语言"""
        cls._current_locale = locale
    
    @classmethod
    def get_locale(cls) -> Locale:
        """获取当前语言"""
        return cls._current_locale
    
    @classmethod
    def t(cls, key: str) -> str:
        """翻译"""
        translations = cls._translations.get(cls._current_locale, {})
        return translations.get(key, key)
    
    @classmethod
    def load_translations(cls) -> None:
        """加载翻译"""
        cls._translations = {
            Locale.ZH_CN: {
                # 通用
                "ok": "确定",
                "cancel": "取消",
                "save": "保存",
                "delete": "删除",
                "edit": "编辑",
                "search": "搜索",
                "loading": "加载中...",
                "error": "错误",
                "success": "成功",
                
                # 导航
                "home": "首页",
                "messages": "消息",
                "contacts": "通讯录",
                "wallet": "钱包",
                "openclaw": "OpenClaw",
                "settings": "设置",
                
                # 消息
                "no_messages": "暂无消息",
                "send_message": "发送消息",
                "message_sent": "消息已发送",
                "message_received": "收到新消息",
                
                # 好友
                "add_friend": "添加好友",
                "remove_friend": "删除好友",
                "friends": "好友",
                "online": "在线",
                "offline": "离线",
                
                # 钱包
                "balance": "余额",
                "transfer": "转账",
                "receive": "收款",
                "transaction_record": "交易记录",
                "transfer_success": "转账成功",
                "transfer_failed": "转账失败",
                
                # OpenClaw
                "connect": "连接",
                "disconnect": "断开",
                "connected": "已连接",
                "not_connected": "未连接",
                "agents": "Agent列表",
                
                # 设置
                "account": "账号",
                "notifications": "通知",
                "privacy": "隐私",
                "about": "关于",
                "logout": "退出登录",
            },
            Locale.EN_US: {
                "ok": "OK",
                "cancel": "Cancel",
                "save": "Save",
                "delete": "Delete",
                "edit": "Edit",
                "search": "Search",
                "loading": "Loading...",
                "error": "Error",
                "success": "Success",
                
                "home": "Home",
                "messages": "Messages",
                "contacts": "Contacts",
                "wallet": "Wallet",
                "openclaw": "OpenClaw",
                "settings": "Settings",
                
                "no_messages": "No messages",
                "send_message": "Send message",
                "message_sent": "Message sent",
                "message_received": "New message",
                
                "add_friend": "Add friend",
                "remove_friend": "Remove friend",
                "friends": "Friends",
                "online": "Online",
                "offline": "Offline",
                
                "balance": "Balance",
                "transfer": "Transfer",
                "receive": "Receive",
                "transaction_record": "Transaction record",
                "transfer_success": "Transfer successful",
                "transfer_failed": "Transfer failed",
                
                "connect": "Connect",
                "disconnect": "Disconnect",
                "connected": "Connected",
                "not_connected": "Not connected",
                "agents": "Agents",
                
                "account": "Account",
                "notifications": "Notifications",
                "privacy": "Privacy",
                "about": "About",
                "logout": "Logout",
            },
        }


# 便捷函数
def t(key: str) -> str:
    """翻译"""
    return I18n.t(key)
