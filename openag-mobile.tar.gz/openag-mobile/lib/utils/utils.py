"""
Utils - 工具函数

实现:
- 加密工具
- 网络工具
- 格式化工具
- 验证工具
"""

import json
import hashlib
import base64
import re
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Optional


class CryptoUtils:
    """加密工具"""
    
    @staticmethod
    def md5(data: str) -> str:
        """MD5哈希"""
        return hashlib.md5(data.encode()).hexdigest()
    
    @staticmethod
    def sha256(data: str) -> str:
        """SHA256哈希"""
        return hashlib.sha256(data.encode()).hexdigest()
    
    @staticmethod
    def base64_encode(data: str) -> str:
        """Base64编码"""
        return base64.b64encode(data.encode()).decode()
    
    @staticmethod
    def base64_decode(data: str) -> str:
        """Base64解码"""
        return base64.b64decode(data.encode()).decode()
    
    @staticmethod
    def generate_token(length: int = 32) -> str:
        """生成随机令牌"""
        import secrets
        return secrets.token_hex(length)
    
    @staticmethod
    def generate_id(prefix: str = "") -> str:
        """生成唯一ID"""
        timestamp = str(time.time()).replace(".", "")
        random_part = hashlib.md5(str(time.time()).encode()).hexdigest()[:8]
        return f"{prefix}{timestamp}{random_part}" if prefix else f"{timestamp}{random_part}"


class NetworkUtils:
    """网络工具"""
    
    @staticmethod
    def is_valid_url(url: str) -> bool:
        """验证URL"""
        pattern = r'^https?://[\w\-]+(\.[\w\-]+)+[/#?]?.*$'
        return re.match(pattern, url) is not None
    
    @staticmethod
    def is_valid_ip(ip: str) -> bool:
        """验证IP地址"""
        pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(pattern, ip):
            return False
        
        parts = ip.split('.')
        return all(0 <= int(part) <= 255 for part in parts)
    
    @staticmethod
    def parse_host_port(address: str) -> Optional[tuple]:
        """解析主机和端口"""
        if ':' in address:
            parts = address.rsplit(':', 1)
            if len(parts) == 2 and parts[1].isdigit():
                return (parts[0], int(parts[1]))
        return None


class FormatUtils:
    """格式化工具"""
    
    @staticmethod
    def format_time(timestamp: float, format_str: str = "%H:%M") -> str:
        """格式化时间"""
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime(format_str)
    
    @staticmethod
    def format_date(timestamp: float, format_str: str = "%Y-%m-%d") -> str:
        """格式化日期"""
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime(format_str)
    
    @staticmethod
    def format_datetime(timestamp: float) -> str:
        """格式化日期时间"""
        dt = datetime.fromtimestamp(timestamp)
        now = datetime.now()
        
        if dt.date() == now.date():
            return dt.strftime("今天 %H:%M")
        
        yesterday = now - timedelta(days=1)
        if dt.date() == yesterday.date():
            return dt.strftime("昨天 %H:%M")
        
        return dt.strftime("%Y-%m-%d %H:%M")
    
    @staticmethod
    def format_file_size(size: int) -> str:
        """格式化文件大小"""
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        
        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1
        
        return f"{size:.2f} {units[unit_index]}"
    
    @staticmethod
    def format_number(num: int) -> str:
        """格式化数字"""
        if num < 1000:
            return str(num)
        elif num < 10000:
            return f"{num / 1000:.1f}K"
        elif num < 1000000:
            return f"{num / 1000:.0f}K"
        elif num < 10000000:
            return f"{num / 1000000:.1f}M"
        else:
            return f"{num / 1000000:.0f}M"
    
    @staticmethod
    def format_currency(amount: int, symbol: str = "¥") -> str:
        """格式化货币"""
        return f"{symbol}{amount:,}"
    
    @staticmethod
    def format_duration(seconds: int) -> str:
        """格式化时长"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            minutes = seconds // 60
            return f"{minutes}分钟"
        elif seconds < 86400:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"
        else:
            days = seconds // 86400
            hours = (seconds % 86400) // 3600
            return f"{days}天{hours}小时"
    
    @staticmethod
    def format_address(address: str, start: int = 6, end: int = 4) -> str:
        """格式化地址（隐藏中间部分）"""
        if len(address) <= start + end:
            return address
        return f"{address[:start]}...{address[-end:]}"


class ValidationUtils:
    """验证工具"""
    
    @staticmethod
    def is_valid_email(email: str) -> bool:
        """验证邮箱"""
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def is_valid_phone(phone: str) -> bool:
        """验证手机号"""
        pattern = r'^1[3-9]\d{9}$'
        return re.match(pattern, phone) is not None
    
    @staticmethod
    def is_valid_agent_id(agent_id: str) -> bool:
        """验证Agent ID"""
        pattern = r'^AG-[A-F0-9]{16}$'
        return re.match(pattern, agent_id.upper()) is not None
    
    @staticmethod
    def is_valid_wallet_address(address: str) -> bool:
        """验证钱包地址"""
        pattern = r'^AGC[a-fA-F0-9]{40}$'
        return re.match(pattern, address) is not None
    
    @staticmethod
    def is_strong_password(password: str) -> bool:
        """验证强密码"""
        if len(password) < 8:
            return False
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
        return sum([has_upper, has_lower, has_digit, has_special]) >= 3


class DateTimeUtils:
    """日期时间工具"""
    
    @staticmethod
    def now() -> float:
        """当前时间戳"""
        return time.time()
    
    @staticmethod
    def today() -> float:
        """今天0点时间戳"""
        dt = datetime.now()
        return datetime(dt.year, dt.month, dt.day).timestamp()
    
    @staticmethod
    def add_days(timestamp: float, days: int) -> float:
        """添加天数"""
        dt = datetime.fromtimestamp(timestamp) + timedelta(days=days)
        return dt.timestamp()
    
    @staticmethod
    def add_hours(timestamp: float, hours: int) -> float:
        """添加小时"""
        dt = datetime.fromtimestamp(timestamp) + timedelta(hours=hours)
        return dt.timestamp()
    
    @staticmethod
    def is_same_day(timestamp1: float, timestamp2: float) -> bool:
        """是否同一天"""
        dt1 = datetime.fromtimestamp(timestamp1)
        dt2 = datetime.fromtimestamp(timestamp2)
        return dt1.date() == dt2.date()
    
    @staticmethod
    def is_yesterday(timestamp: float) -> bool:
        """是否是昨天"""
        yesterday = datetime.now() - timedelta(days=1)
        dt = datetime.fromtimestamp(timestamp)
        return dt.date() == yesterday.date()


class JSONUtils:
    """JSON工具"""
    
    @staticmethod
    def to_json(data: Any) -> str:
        """转换为JSON"""
        return json.dumps(data, ensure_ascii=False)
    
    @staticmethod
    def from_json(json_str: str) -> Any:
        """从JSON解析"""
        try:
            return json.loads(json_str)
        except:
            return None
    
    @staticmethod
    def pretty_print(data: Any) -> str:
        """格式化输出"""
        return json.dumps(data, ensure_ascii=False, indent=2)


class Utils:
    """工具汇总"""
    
    crypto = CryptoUtils()
    network = NetworkUtils()
    format = FormatUtils()
    validation = ValidationUtils()
    datetime = DateTimeUtils()
    json = JSONUtils()
