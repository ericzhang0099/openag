"""
Local Storage - 本地数据存储

实现:
- SQLite数据库
- Hive缓存
- 安全存储
"""

import json
import time
import sqlite3
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class DBConfig:
    """数据库配置"""
    name: str = "openag.db"
    version: int = 1


class Database:
    """SQLite数据库"""
    
    def __init__(self, config: DBConfig = None):
        self.config = config or DBConfig()
        self._conn = None
    
    def connect(self, path: str = None) -> None:
        """连接数据库"""
        db_path = path or self.config.name
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._create_tables()
    
    def _create_tables(self) -> None:
        """创建表"""
        cursor = self._conn.cursor()
        
        # 用户表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                avatar TEXT,
                agent_id TEXT,
                created_at REAL
            )
        """)
        
        # 好友表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS friends (
                user_id TEXT,
                friend_id TEXT,
                status TEXT,
                added_at REAL,
                PRIMARY KEY (user_id, friend_id)
            )
        """)
        
        # 消息表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                message_id TEXT PRIMARY KEY,
                chat_id TEXT,
                sender_id TEXT,
                message_type TEXT,
                content TEXT,
                timestamp REAL,
                read INTEGER
            )
        """)
        
        # 聊天表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chats (
                chat_id TEXT PRIMARY KEY,
                chat_type TEXT,
                name TEXT,
                members TEXT,
                created_at REAL,
                last_message_time REAL
            )
        """)
        
        # 钱包表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS wallets (
                wallet_id TEXT PRIMARY KEY,
                agent_id TEXT,
                address TEXT,
                balance INTEGER,
                created_at REAL
            )
        """)
        
        # 交易表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                tx_id TEXT PRIMARY KEY,
                from_address TEXT,
                to_address TEXT,
                amount INTEGER,
                fee INTEGER,
                status TEXT,
                timestamp REAL
            )
        """)
        
        # 设置表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        
        self._conn.commit()
    
    def execute(self, sql: str, params: tuple = None) -> None:
        """执行SQL"""
        cursor = self._conn.cursor()
        cursor.execute(sql, params or ())
        self._conn.commit()
    
    def query(self, sql: str, params: tuple = None) -> List[Dict]:
        """查询"""
        cursor = self._conn.cursor()
        cursor.execute(sql, params or ())
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    def close(self) -> None:
        """关闭连接"""
        if self._conn:
            self._conn.close()


class Cache:
    """缓存管理"""
    
    def __init__(self):
        self._data: Dict[str, Dict[str, Any]] = {}
        self._expiry: Dict[str, float] = {}
    
    def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        """设置缓存"""
        self._data[key] = value
        self._expiry[key] = time.time() + ttl
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存"""
        if key not in self._data:
            return None
        
        if key in self._expiry and time.time() > self._expiry[key]:
            del self._data[key]
            del self._expiry[key]
            return None
        
        return self._data[key]
    
    def delete(self, key: str) -> None:
        """删除缓存"""
        if key in self._data:
            del self._data[key]
        if key in self._expiry:
            del self._expiry[key]
    
    def clear(self) -> None:
        """清空缓存"""
        self._data.clear()
        self._expiry.clear()
    
    def keys(self) -> List[str]:
        """获取所有键"""
        return list(self._data.keys())


class SecureStorage:
    """安全存储"""
    
    def __init__(self):
        self._data: Dict[str, str] = {}
    
    def set(self, key: str, value: str) -> None:
        """存储"""
        self._data[key] = value
    
    def get(self, key: str) -> Optional[str]:
        """读取"""
        return self._data.get(key)
    
    def delete(self, key: str) -> None:
        """删除"""
        if key in self._data:
            del self._data[key]
    
    def clear(self) -> None:
        """清空"""
        self._data.clear()
    
    def has(self, key: str) -> bool:
        """检查是否存在"""
        return key in self._data


class PreferenceManager:
    """偏好设置管理"""
    
    def __init__(self, storage: SecureStorage):
        self._storage = storage
        self._defaults = {
            "theme": "light",
            "language": "zh-CN",
            "notifications_enabled": True,
            "sound_enabled": True,
            "vibration_enabled": True,
            "auto_lock": True,
            "lock_timeout": 300,
            "data_saver": False,
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取设置"""
        value = self._storage.get(key)
        if value is None:
            return self._defaults.get(key, default)
        
        try:
            return json.loads(value)
        except:
            return value
    
    def set(self, key: str, value: Any) -> None:
        """设置"""
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        self._storage.set(key, str(value))
    
    def get_all(self) -> Dict:
        """获取所有设置"""
        result = self._defaults.copy()
        for key in self._data.keys():
            result[key] = self.get(key)
        return result
    
    @property
    def _data(self) -> Dict:
        return {}


class DataManager:
    """数据管理器"""
    
    def __init__(self):
        self.db = Database()
        self.cache = Cache()
        self.secure = SecureStorage()
        self.preferences = PreferenceManager(self.secure)
    
    def initialize(self) -> None:
        """初始化"""
        self.db.connect()
    
    def close(self) -> None:
        """关闭"""
        self.db.close()
