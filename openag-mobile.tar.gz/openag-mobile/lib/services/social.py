"""
Social Module - 社交功能

实现:
- 好友系统 (Agent发现)
- 消息系统
- 群组系统
- 文件传输
"""

import json
import time
import uuid
import asyncio
import hashlib
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field


class EntityType(str, Enum):
    """实体类型"""
    USER = "user"
    AGENT = "agent"
    GROUP = "group"


class MessageType(str, Enum):
    """消息类型"""
    TEXT = "text"
    IMAGE = "image"
    FILE = "file"
    AUDIO = "audio"
    VIDEO = "video"
    SYSTEM = "system"


class FriendStatus(str, Enum):
    """好友状态"""
    NONE = "none"
    PENDING = "pending"
    FRIEND = "friend"
    BLOCKED = "blocked"


@dataclass
class User:
    """用户"""
    user_id: str
    name: str
    avatar: Optional[str] = None
    agent_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Friend:
    """好友关系"""
    user_id: str
    friend_id: str
    status: FriendStatus = FriendStatus.NONE
    added_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChatMessage:
    """聊天消息"""
    message_id: str
    chat_id: str
    sender_id: str
    message_type: MessageType
    content: str
    timestamp: float = field(default_factory=time.time)
    read: bool = False
    reactions: List[Dict] = field(default_factory=list)
    reply_to: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.message_id:
            self.message_id = str(uuid.uuid4())


@dataclass
class Chat:
    """聊天会话"""
    chat_id: str
    chat_type: str  # "private", "group"
    name: Optional[str] = None
    members: List[str] = field(default_factory=list)
    owner_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    last_message_time: float = field(default_factory=time.time)
    unread_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


# ==================== Friend System ====================

class FriendSystem:
    """好友系统"""
    
    def __init__(self):
        self._friends: Dict[str, Dict[str, Friend]] = {}  # user_id -> {friend_id -> Friend}
        self._pending_requests: Dict[str, List[Friend]] = {}
        self._search_index: Dict[str, List[str]] = {}  # name -> [user_ids]
    
    def generate_agent_id(self, user_id: str, gene_hash: str = None) -> str:
        """生成Agent ID"""
        if gene_hash:
            seed = f"{user_id}:{gene_hash}"
        else:
            seed = f"{user_id}:{time.time()}"
        
        hash_value = hashlib.sha256(seed.encode()).hexdigest()[:16]
        return f"AG-{hash_value.upper()}"
    
    def generate_gene_hash(self, biometric_data: str) -> str:
        """生成生物特征哈希"""
        return hashlib.sha256(biometric_data.encode()).hexdigest()
    
    def add_friend(self, user_id: str, friend_id: str) -> Friend:
        """添加好友"""
        if user_id not in self._friends:
            self._friends[user_id] = {}
        
        friend = Friend(
            user_id=user_id,
            friend_id=friend_id,
            status=FriendStatus.FRIEND
        )
        
        self._friends[user_id][friend_id] = friend
        return friend
    
    def remove_friend(self, user_id: str, friend_id: str) -> bool:
        """删除好友"""
        if user_id in self._friends and friend_id in self._friends[user_id]:
            del self._friends[user_id][friend_id]
            return True
        return False
    
    def get_friends(self, user_id: str) -> List[Friend]:
        """获取好友列表"""
        if user_id not in self._friends:
            return []
        
        return [
            f for f in self._friends[user_id].values()
            if f.status == FriendStatus.FRIEND
        ]
    
    def is_friend(self, user_id: str, other_id: str) -> bool:
        """检查是否是好友"""
        if user_id not in self._friends:
            return False
        
        friend = self._friends[user_id].get(other_id)
        return friend and friend.status == FriendStatus.FRIEND
    
    def search_by_name(self, name: str) -> List[str]:
        """通过名字搜索"""
        name_lower = name.lower()
        results = []
        
        for key, user_ids in self._search_index.items():
            if name_lower in key:
                results.extend(user_ids)
        
        return list(set(results))
    
    def search_by_agent_id(self, agent_id: str) -> Optional[str]:
        """通过Agent ID搜索"""
        # 简化实现
        return None
    
    def search_by_gene(self, gene_hash: str) -> Optional[str]:
        """通过生物特征搜索"""
        # 简化实现
        return None
    
    def register_user(self, user_id: str, name: str, agent_id: str) -> None:
        """注册用户到搜索索引"""
        name_lower = name.lower()
        
        if name_lower not in self._search_index:
            self._search_index[name_lower] = []
        
        if user_id not in self._search_index[name_lower]:
            self._search_index[name_lower].append(user_id)
    
    def block_user(self, user_id: str, blocked_id: str) -> bool:
        """拉黑用户"""
        if user_id not in self._friends:
            self._friends[user_id] = {}
        
        friend = Friend(
            user_id=user_id,
            friend_id=blocked_id,
            status=FriendStatus.BLOCKED
        )
        
        self._friends[user_id][blocked_id] = friend
        return True


# ==================== Message System ====================

class MessageSystem:
    """消息系统"""
    
    def __init__(self):
        self._chats: Dict[str, Chat] = {}
        self._messages: Dict[str, List[ChatMessage]] = {}  # chat_id -> messages
        self._offline_messages: Dict[str, List[ChatMessage]] = {}  # user_id -> offline messages
        self._callbacks: List[Callable] = []
    
    def create_chat(
        self,
        chat_type: str,
        members: List[str],
        owner_id: str = None,
        name: str = None
    ) -> Chat:
        """创建聊天"""
        chat_id = str(uuid.uuid4())
        
        chat = Chat(
            chat_id=chat_id,
            chat_type=chat_type,
            name=name,
            members=members,
            owner_id=owner_id
        )
        
        self._chats[chat_id] = chat
        self._messages[chat_id] = []
        
        return chat
    
    def get_chat(self, chat_id: str) -> Optional[Chat]:
        """获取聊天"""
        return self._chats.get(chat_id)
    
    def get_user_chats(self, user_id: str) -> List[Chat]:
        """获取用户的所有聊天"""
        return [
            chat for chat in self._chats.values()
            if user_id in chat.members
        ]
    
    def send_message(
        self,
        chat_id: str,
        sender_id: str,
        content: str,
        message_type: MessageType = MessageType.TEXT
    ) -> ChatMessage:
        """发送消息"""
        message = ChatMessage(
            message_id=str(uuid.uuid4()),
            chat_id=chat_id,
            sender_id=sender_id,
            message_type=message_type,
            content=content
        )
        
        if chat_id not in self._messages:
            self._messages[chat_id] = []
        
        self._messages[chat_id].append(message)
        
        # 更新聊天最后消息时间
        if chat_id in self._chats:
            self._chats[chat_id].last_message_time = time.time()
        
        # 触发回调
        for callback in self._callbacks:
            asyncio.create_task(callback(message))
        
        return message
    
    def get_messages(
        self,
        chat_id: str,
        limit: int = 50,
        before: float = None
    ) -> List[ChatMessage]:
        """获取消息历史"""
        if chat_id not in self._messages:
            return []
        
        messages = self._messages[chat_id]
        
        if before:
            messages = [m for m in messages if m.timestamp < before]
        
        messages.sort(key=lambda x: x.timestamp, reverse=True)
        return messages[:limit]
    
    def mark_read(self, chat_id: str, user_id: str) -> int:
        """标记已读"""
        count = 0
        
        if chat_id in self._messages:
            for msg in self._messages[chat_id]:
                if msg.sender_id != user_id and not msg.read:
                    msg.read = True
                    count += 1
        
        if chat_id in self._chats:
            self._chats[chat_id].unread_count = 0
        
        return count
    
    def add_reaction(
        self,
        message_id: str,
        chat_id: str,
        user_id: str,
        emoji: str
    ) -> bool:
        """添加反应"""
        if chat_id not in self._messages:
            return False
        
        for msg in self._messages[chat_id]:
            if msg.message_id == message_id:
                msg.reactions.append({
                    "user_id": user_id,
                    "emoji": emoji,
                    "timestamp": time.time()
                })
                return True
        
        return False
    
    def store_offline_message(self, user_id: str, message: ChatMessage) -> None:
        """存储离线消息"""
        if user_id not in self._offline_messages:
            self._offline_messages[user_id] = []
        
        self._offline_messages[user_id].append(message)
    
    def get_offline_messages(self, user_id: str) -> List[ChatMessage]:
        """获取离线消息"""
        messages = self._offline_messages.get(user_id, [])
        self._offline_messages[user_id] = []
        return messages
    
    def on_message(self, callback: Callable) -> None:
        """消息回调"""
        self._callbacks.append(callback)


# ==================== Group System ====================

class GroupSystem:
    """群组系统"""
    
    def __init__(self):
        self._groups: Dict[str, Group] = {}
        self._members: Dict[str, List[str]] = {}  # group_id -> [user_ids]
        self._admins: Dict[str, List[str]] = {}   # group_id -> [user_ids]
    
    def create_group(
        self,
        name: str,
        owner_id: str,
        member_ids: List[str] = None
    ) -> Group:
        """创建群组"""
        group_id = str(uuid.uuid4())
        
        members = [owner_id]
        if member_ids:
            members.extend(member_ids)
        
        group = Group(
            group_id=group_id,
            name=name,
            owner_id=owner_id,
            members=members
        )
        
        self._groups[group_id] = group
        self._members[group_id] = members
        self._admins[group_id] = [owner_id]
        
        return group
    
    def get_group(self, group_id: str) -> Optional[Group]:
        """获取群组"""
        return self._groups.get(group_id)
    
    def add_member(
        self,
        group_id: str,
        user_id: str,
        added_by: str
    ) -> bool:
        """添加成员"""
        if group_id not in self._groups:
            return False
        
        group = self._groups[group_id]
        
        if user_id in group.members:
            return False
        
        group.members.append(user_id)
        
        if group_id in self._members:
            self._members[group_id].append(user_id)
        
        return True
    
    def remove_member(
        self,
        group_id: str,
        user_id: str,
        removed_by: str
    ) -> bool:
        """移除成员"""
        if group_id not in self._groups:
            return False
        
        group = self._groups[group_id]
        
        if user_id not in group.members:
            return False
        
        # 只有群主或管理员可以移除
        if removed_by != group.owner_id:
            if group_id not in self._admins or removed_by not in self._admins[group_id]:
                return False
        
        group.members.remove(user_id)
        
        if group_id in self._members and user_id in self._members[group_id]:
            self._members[group_id].remove(user_id)
        
        return True
    
    def set_admin(
        self,
        group_id: str,
        user_id: str,
        set_by: str
    ) -> bool:
        """设置管理员"""
        if group_id not in self._groups:
            return False
        
        group = self._groups[group_id]
        
        # 只有群主可以设置管理员
        if set_by != group.owner_id:
            return False
        
        if group_id not in self._admins:
            self._admins[group_id] = []
        
        if user_id not in self._admins[group_id]:
            self._admins[group_id].append(user_id)
        
        return True
    
    def is_admin(self, group_id: str, user_id: str) -> bool:
        """检查是否是管理员"""
        if group_id not in self._admins:
            return False
        return user_id in self._admins[group_id]
    
    def get_member_count(self, group_id: str) -> int:
        """获取成员数量"""
        if group_id not in self._groups:
            return 0
        return len(self._groups[group_id].members)


# ==================== File Transfer ====================

class FileTransfer:
    """文件传输"""
    
    def __init__(self):
        self._files: Dict[str, Dict[str, Any]] = {}
        self._upload_callbacks: List[Callable] = []
        self._download_callbacks: List[Callable] = []
    
    async def upload(
        self,
        file_data: bytes,
        filename: str,
        uploader_id: str,
        file_type: str = None
    ) -> Optional[str]:
        """上传文件"""
        file_id = str(uuid.uuid4())
        
        # 计算文件哈希
        file_hash = hashlib.sha256(file_data).hexdigest()
        
        file_info = {
            "file_id": file_id,
            "filename": filename,
            "file_type": file_type or self._guess_type(filename),
            "size": len(file_data),
            "hash": file_hash,
            "uploader_id": uploader_id,
            "uploaded_at": time.time(),
            "download_count": 0
        }
        
        self._files[file_id] = file_info
        
        # 触发回调
        for callback in self._upload_callbacks:
            await callback(file_info)
        
        return file_id
    
    async def download(self, file_id: str) -> Optional[bytes]:
        """下载文件"""
        if file_id not in self._files:
            return None
        
        self._files[file_id]["download_count"] += 1
        
        # 触发回调
        for callback in self._download_callbacks:
            await callback(self._files[file_id])
        
        # 模拟返回文件数据
        return b"file_content"
    
    def get_file_info(self, file_id: str) -> Optional[Dict]:
        """获取文件信息"""
        return self._files.get(file_id)
    
    def _guess_type(self, filename: str) -> str:
        """猜测文件类型"""
        ext = filename.split('.')[-1].lower() if '.' in filename else ''
        
        types = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'pdf': 'application/pdf',
            'doc': 'application/msword',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'mp3': 'audio/mpeg',
            'mp4': 'video/mp4',
            'zip': 'application/zip'
        }
        
        return types.get(ext, 'application/octet-stream')
    
    def on_upload(self, callback: Callable) -> None:
        """上传回调"""
        self._upload_callbacks.append(callback)
    
    def on_download(self, callback: Callable) -> None:
        """下载回调"""
        self._download_callbacks.append(callback)


# ==================== Social Manager ====================

class SocialManager:
    """社交管理器"""
    
    def __init__(self):
        self.friends = FriendSystem()
        self.messages = MessageSystem()
        self.groups = GroupSystem()
        self.files = FileTransfer()
    
    def_chat(
        create_private self,
        user1_id: str,
        user2_id: str
    ) -> Chat:
        """创建私聊"""
        return self.messages.create_chat(
            chat_type="private",
            members=[user1_id, user2_id]
        )
    
    def create_group_chat(
        self,
        name: str,
        owner_id: str,
        member_ids: List[str]
    ) -> Chat:
        """创建群聊"""
        return self.messages.create_chat(
            chat_type="group",
            members=[owner_id] + member_ids,
            owner_id=owner_id,
            name=name
        )
    
    def transfer_message(
        self,
        from_agent_id: str,
        to_agent_id: str,
        content: str
    ) -> ChatMessage:
        """Agent到Agent的消息转发"""
        # 查找或创建聊天
        chats = self.messages.get_user_chats(from_agent_id)
        chat = None
        
        for c in chats:
            if c.chat_type == "private" and to_agent_id in c.members:
                chat = c
                break
        
        if not chat:
            chat = self.create_private_chat(from_agent_id, to_agent_id)
        
        # 发送消息
        return self.messages.send_message(
            chat_id=chat.chat_id,
            sender_id=from_agent_id,
            content=content
        )
    
    def get_status(self) -> Dict:
        """获取状态"""
        return {
            "friends_count": sum(len(f) for f in self.friends._friends.values()),
            "chats_count": len(self.messages._chats),
            "groups_count": len(self.groups._groups),
            "files_count": len(self.files._files)
        }
