"""
Analytics - 数据分析

实现:
- 用户行为分析
- 消息分析
- 统计分析
- 数据可视化
- 报表生成
"""

import time
import json
from typing import Dict, List, Any
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class AnalyticsEvent:
    """分析事件"""
    event_id: str
    event_type: str
    user_id: str
    properties: Dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class UserStats:
    """用户统计"""
    user_id: str
    message_count: int = 0
    friend_count: int = 0
    group_count: int = 0
    online_time: int = 0  # 秒
    first_active: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)


@dataclass
class MessageStats:
    """消息统计"""
    total_messages: int = 0
    text_messages: int = 0
    image_messages: int = 0
    file_messages: int = 0
    avg_length: float = 0
    peak_hour: int = 0


class AnalyticsManager:
    """分析管理器"""
    
    def __init__(self):
        self._events: List[AnalyticsEvent] = []
        self._user_stats: Dict[str, UserStats] = {}
        self._message_stats = MessageStats()
        self._hourly_stats: Dict[int, int] = defaultdict(int)
    
    # ========== 事件跟踪 ==========
    def track_event(
        self,
        event_type: str,
        user_id: str,
        properties: Dict = None
    ) -> AnalyticsEvent:
        """跟踪事件"""
        event = AnalyticsEvent(
            event_id=f"evt_{int(time.time() * 1000)}",
            event_type=event_type,
            user_id=user_id,
            properties=properties or {}
        )
        
        self._events.append(event)
        
        # 更新用户统计
        self._update_user_stats(user_id, event_type)
        
        return event
    
    def _update_user_stats(self, user_id: str, event_type: str) -> None:
        """更新用户统计"""
        if user_id not in self._user_stats:
            self._user_stats[user_id] = UserStats(user_id=user_id)
        
        stats = self._user_stats[user_id]
        stats.last_active = time.time()
        
        if event_type == "message_sent":
            stats.message_count += 1
    
    # ========== 用户分析 ==========
    def get_user_stats(self, user_id: str) -> UserStats:
        """获取用户统计"""
        return self._user_stats.get(user_id, UserStats(user_id=user_id))
    
    def get_top_users(self, limit: int = 10) -> List[UserStats]:
        """获取活跃用户排行"""
        users = list(self._user_stats.values())
        users.sort(key=lambda x: x.message_count, reverse=True)
        return users[:limit]
    
    def get_user_activity(self, user_id: str) -> Dict[str, Any]:
        """获取用户活跃度"""
        stats = self._user_stats.get(user_id)
        if not stats:
            return {"active": False}
        
        days_since_first = (time.time() - stats.first_active) / 86400
        days_since_last = (time.time() - stats.last_active) / 86400
        
        return {
            "active": days_since_last < 7,
            "days_active": int(days_since_first),
            "message_count": stats.message_count,
            "daily_avg": stats.message_count / max(1, days_since_first),
            "last_active": stats.last_active
        }
    
    # ========== 消息分析 ==========
    def analyze_message(self, message_type: str, content: str) -> None:
        """分析消息"""
        self._message_stats.total_messages += 1
        
        if message_type == "text":
            self._message_stats.text_messages += 1
            self._message_stats.avg_length = (
                (self._message_stats.avg_length * (self._message_stats.text_messages - 1) + len(content))
                / self._message_stats.text_messages
            )
        elif message_type == "image":
            self._message_stats.image_messages += 1
        elif message_type == "file":
            self._message_stats.file_messages += 1
        
        # 更新小时统计
        hour = int(time.localtime().tm_hour)
        self._hourly_stats[hour] += 1
    
    def get_message_stats(self) -> MessageStats:
        """获取消息统计"""
        return self._message_stats
    
    def get_peak_hours(self, limit: int = 3) -> List[tuple]:
        """获取高峰时段"""
        sorted_hours = sorted(
            self._hourly_stats.items(),
            key=lambda x: x[1],
            reverse=True
        )
        return sorted_hours[:limit]
    
    def get_message_distribution(self) -> Dict[str, float]:
        """获取消息类型分布"""
        total = self._message_stats.total_messages
        if total == 0:
            return {}
        
        return {
            "text": self._message_stats.text_messages / total,
            "image": self._message_stats.image_messages / total,
            "file": self._message_stats.file_messages / total
        }
    
    # ========== 报表生成 ==========
    def generate_report(self, period: str = "day") -> Dict[str, Any]:
        """生成报表"""
        now = time.time()
        
        if period == "day":
            start_time = now - 86400
        elif period == "week":
            start_time = now - 604800
        elif period == "month":
            start_time = now - 2592000
        else:
            start_time = 0
        
        # 过滤事件
        period_events = [e for e in self._events if e.timestamp >= start_time]
        
        # 生成报表
        report = {
            "period": period,
            "start_time": start_time,
            "end_time": now,
            "total_events": len(period_events),
            "unique_users": len(set(e.user_id for e in period_events)),
            "message_count": sum(1 for e in period_events if e.event_type == "message_sent"),
            "top_users": [
                {"user_id": u.user_id, "messages": u.message_count}
                for u in self.get_top_users(5)
            ],
            "peak_hours": [{"hour": h, "count": c} for h, c in self.get_peak_hours()],
            "message_distribution": self.get_message_distribution()
        }
        
        return report
    
    # ========== 导出 ==========
    def export_json(self) -> str:
        """导出为JSON"""
        data = {
            "events": [
                {
                    "event_id": e.event_id,
                    "event_type": e.event_type,
                    "user_id": e.user_id,
                    "properties": e.properties,
                    "timestamp": e.timestamp
                }
                for e in self._events
            ],
            "user_stats": {
                uid: {
                    "message_count": stats.message_count,
                    "online_time": stats.online_time
                }
                for uid, stats in self._user_stats.items()
            }
        }
        
        return json.dumps(data, indent=2)


# ========== 埋点系统 ==========

class Tracker:
    """埋点跟踪器"""
    
    def __init__(self, analytics: AnalyticsManager):
        self._analytics = analytics
    
    def track_screen_view(self, user_id: str, screen_name: str) -> None:
        """跟踪页面浏览"""
        self._analytics.track_event(
            event_type="screen_view",
            user_id=user_id,
            properties={"screen_name": screen_name}
        )
    
    def track_button_click(self, user_id: str, button_id: str) -> None:
        """跟踪按钮点击"""
        self._analytics.track_event(
            event_type="button_click",
            user_id=user_id,
            properties={"button_id": button_id}
        )
    
    def track_error(self, user_id: str, error: str, stack: str = "") -> None:
        """跟踪错误"""
        self._analytics.track_event(
            event_type="error",
            user_id=user_id,
            properties={"error": error, "stack": stack}
        )
    
    def track_performance(self, user_id: str, metric: str, value: float) -> None:
        """跟踪性能"""
        self._analytics.track_event(
            event_type="performance",
            user_id=user_id,
            properties={"metric": metric, "value": value}
        )


# 全局实例
analytics = AnalyticsManager()
tracker = Tracker(analytics)
