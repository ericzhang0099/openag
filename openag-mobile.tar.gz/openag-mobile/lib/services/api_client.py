"""
API Client - API客户端

实现:
- HTTP客户端
- WebSocket客户端
- 请求/响应拦截器
"""

import json
import asyncio
from enum import Enum
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass


class HttpMethod(str, Enum):
    """HTTP方法"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


@dataclass
class Request:
    """请求"""
    method: HttpMethod
    url: str
    headers: Dict[str, str] = None
    body: Any = None
    timeout: int = 30


@dataclass
class Response:
    """响应"""
    status_code: int
    body: Any
    headers: Dict[str, str] = None
    error: Optional[str] = None


class ApiClient:
    """API客户端"""
    
    def __init__(self, base_url: str = ""):
        self._base_url = base_url
        self._default_headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self._interceptors_request: list = []
        self._interceptors_response: list = []
        self._token: Optional[str] = None
    
    def set_base_url(self, url: str) -> None:
        """设置基础URL"""
        self._base_url = url
    
    def set_token(self, token: str) -> None:
        """设置Token"""
        self._token = token
        self._default_headers["Authorization"] = f"Bearer {token}"
    
    def add_request_interceptor(self, interceptor: Callable) -> None:
        """添加请求拦截器"""
        self._interceptors_request.append(interceptor)
    
    def add_response_interceptor(self, interceptor: Callable) -> None:
        """添加响应拦截器"""
        self._interceptors_response.append(interceptor)
    
    async def request(self, request: Request) -> Response:
        """发送请求"""
        url = self._base_url + request.url if request.url else self._base_url
        
        headers = {**self._default_headers}
        if request.headers:
            headers.update(request.headers)
        
        # 请求拦截
        for interceptor in self._interceptors_request:
            await interceptor(request)
        
        try:
            # 实际请求（简化实现）
            await asyncio.sleep(0.1)  # 模拟网络延迟
            
            # 模拟响应
            response = Response(
                status_code=200,
                body={"success": True},
                headers={"Content-Type": "application/json"}
            )
            
            # 响应拦截
            for interceptor in self._interceptors_response:
                response = await interceptor(response)
            
            return response
            
        except Exception as e:
            return Response(
                status_code=500,
                body=None,
                error=str(e)
            )
    
    async def get(self, url: str, params: Dict = None, **kwargs) -> Response:
        """GET请求"""
        return await self.request(Request(
            method=HttpMethod.GET,
            url=url,
            **kwargs
        ))
    
    async def post(self, url: str, data: Any = None, **kwargs) -> Response:
        """POST请求"""
        return await self.request(Request(
            method=HttpMethod.POST,
            url=url,
            body=json.dumps(data) if data else None,
            **kwargs
        ))
    
    async def put(self, url: str, data: Any = None, **kwargs) -> Response:
        """PUT请求"""
        return await self.request(Request(
            method=HttpMethod.PUT,
            url=url,
            body=json.dumps(data) if data else None,
            **kwargs
        ))
    
    async def delete(self, url: str, **kwargs) -> Response:
        """DELETE请求"""
        return await self.request(Request(
            method=HttpMethod.DELETE,
            url=url,
            **kwargs
        ))


class WebSocketClient:
    """WebSocket客户端"""
    
    def __init__(self):
        self._ws = None
        self._connected = False
        self._reconnect = True
        self._message_handlers: Dict[str, Callable] = {}
        self._ping_interval = 30
    
    async def connect(self, url: str) -> bool:
        """连接"""
        try:
            # 模拟连接
            await asyncio.sleep(0.3)
            self._connected = True
            return True
        except Exception:
            return False
    
    async def disconnect(self) -> None:
        """断开"""
        self._connected = False
        self._reconnect = False
    
    async def send(self, data: Any) -> bool:
        """发送消息"""
        if not self._connected:
            return False
        
        try:
            # 模拟发送
            return True
        except Exception:
            return False
    
    def on(self, event: str, handler: Callable) -> None:
        """注册消息处理器"""
        self._message_handlers[event] = handler
    
    async def _handle_message(self, data: Dict) -> None:
        """处理消息"""
        event_type = data.get("type", "message")
        
        if event_type in self._message_handlers:
            await self._message_handlers[event_type](data)
    
    async def _ping_loop(self) -> None:
        """心跳"""
        while self._connected and self._reconnect:
            await asyncio.sleep(self._ping_interval)
            if self._connected:
                await self.send({"type": "ping"})
    
    @property
    def is_connected(self) -> bool:
        return self._connected


class API:
    """API接口封装"""
    
    def __init__(self):
        self.client = ApiClient()
        self.ws = WebSocketClient()
    
    # ========== Auth API ==========
    async def login(self, username: str, password: str) -> Response:
        return await self.client.post("/api/auth/login", {
            "username": username,
            "password": password
        })
    
    async def register(self, username: str, password: str, email: str) -> Response:
        return await self.client.post("/api/auth/register", {
            "username": username,
            "password": password,
            "email": email
        })
    
    async def logout(self) -> Response:
        return await self.client.post("/api/auth/logout")
    
    # ========== Agent API ==========
    async def get_agents(self) -> Response:
        return await self.client.get("/api/agents")
    
    async def get_agent(self, agent_id: str) -> Response:
        return await self.client.get(f"/api/agents/{agent_id}")
    
    async def create_agent(self, name: str, config: Dict) -> Response:
        return await self.client.post("/api/agents", {
            "name": name,
            "config": config
        })
    
    # ========== Message API ==========
    async def send_message(self, to_agent_id: str, content: str) -> Response:
        return await self.client.post("/api/messages", {
            "to": to_agent_id,
            "content": content
        })
    
    async def get_messages(self, chat_id: str, limit: int = 50) -> Response:
        return await self.client.get(f"/api/chats/{chat_id}/messages", {
            "limit": limit
        })
    
    async def get_chats(self) -> Response:
        return await self.client.get("/api/chats")
    
    # ========== Wallet API ==========
    async def get_balance(self) -> Response:
        return await self.client.get("/api/wallet/balance")
    
    async def transfer(self, to_address: str, amount: int) -> Response:
        return await self.client.post("/api/wallet/transfer", {
            "to": to_address,
            "amount": amount
        })
    
    async def get_transactions(self, limit: int = 50) -> Response:
        return await self.client.get("/api/wallet/transactions", {
            "limit": limit
        })
    
    # ========== OpenClaw API ==========
    async def connect_openclaw(self, host: str, port: int) -> bool:
        return await self.ws.connect(f"ws://{host}:{port}/ws")
    
    async def get_openclaw_agents(self) -> Response:
        return await self.client.get("/api/openclaw/agents")
    
    async def execute_task(self, agent_id: str, task: str, params: Dict) -> Response:
        return await self.client.post(f"/api/openclaw/agents/{agent_id}/tasks", {
            "task": task,
            "params": params
        })


# 全局API实例
api = API()
