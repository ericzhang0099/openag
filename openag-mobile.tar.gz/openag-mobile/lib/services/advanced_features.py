"""
Advanced Features - 高级功能

包含:
- 加密通讯
- 离线消息
- 消息撤回/编辑
- 阅后即焚
- 定时消息
- 机器人功能
- 消息引用
- 提醒功能
"""

import time
import uuid
import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field


# ==================== 消息类型扩展 ====================

class MessageType(str, Enum):
    """消息类型"""
    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    FILE = "file"
    STICKER = "sticker"
    SYSTEM = "system"
    REPLY = "reply"
    FORWARD = "forward"
    BURN = "burn"  # 阅后即焚
    TIMED = "timed"  # 定时消息


class MessageStatus(str, Enum):
    """消息状态"""
    SENDING = "sending"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"
    BURNED = "burned"  # 已焚毁


@dataclass
class AdvancedMessage:
    """高级消息"""
    message_id: str
    chat_id: str
    sender_id: str
    message_type: MessageType
    content: str
    timestamp: float = field(default_factory=time.time)
    status: MessageStatus = MessageStatus.SENDING
    
    # 扩展功能
    reply_to: Optional[str] = None  # 回复
    forward_from: Optional[str] = None  # 转发
    burn_after_read: bool = False  # 阅后即焚
    burn_at: Optional[float] = None  # 焚毁时间
    scheduled_at: Optional[float] = None  # 定时发送
    edited_at: Optional[float] = None  # 编辑时间
    reactions: List[Dict] = field(default_factory=list)  # 表情反应
    mentions: List[str] = field(default_factory=list)  # 提及
    
    # 加密
    encrypted: bool = False
    encryption_key: Optional[str] = None
    
    # 附件
    attachments: List[Dict] = field(default_factory=list)


# ==================== 消息管理器 ====================

class MessageManager:
    """消息管理器"""
    
    def __init__(self):
        self._messages: Dict[str, AdvancedMessage] = {}
        self._drafts: Dict[str, str] = {}  # 草稿
        self._pinned: Dict[str, List[str]] = {}  # 置顶消息
        self._callbacks: Dict[str, List[Callable]] = {}
    
    def send_message(
        self,
        chat_id: str,
        sender_id: str,
        content: str,
        message_type: MessageType = MessageType.TEXT,
        reply_to: Optional[str] = None,
        burn_after_read: bool = False,
        scheduled_at: Optional[float] = None
    ) -> AdvancedMessage:
        """发送消息"""
        message = AdvancedMessage(
            message_id=str(uuid.uuid4()),
            chat_id=chat_id,
            sender_id=sender_id,
            message_type=message_type,
            content=content,
            reply_to=reply_to,
            burn_after_read=burn_after_read,
            scheduled_at=scheduled_at,
            status=MessageStatus.SENDING if not scheduled_at else MessageStatus.SENDING
        )
        
        self._messages[message.message_id] = message
        
        # 触发回调
        self._trigger("message_sent", message)
        
        return message
    
    def edit_message(self, message_id: str, new_content: str) -> bool:
        """编辑消息"""
        if message_id not in self._messages:
            return False
        
        message = self._messages[message_id]
        message.content = new_content
        message.edited_at = time.time()
        
        self._trigger("message_edited", message)
        return True
    
    def delete_message(self, message_id: str) -> bool:
        """删除消息"""
        if message_id not in self._messages:
            return False
        
        del self._messages[message_id]
        self._trigger("message_deleted", message_id)
        return True
    
    def recall_message(self, message_id: str, reason: str = "") -> bool:
        """撤回消息"""
        if message_id not in self._messages:
            return False
        
        message = self._messages[message_id]
        message.status = MessageStatus.FAILED
        message.content = f"消息已撤回: {reason}"
        
        self._trigger("message_recalled", message)
        return True
    
    def forward_message(
        self,
        message_id: str,
        to_chat_id: str,
        sender_id: str
    ) -> Optional[AdvancedMessage]:
        """转发消息"""
        original = self._messages.get(message_id)
        if not original:
            return None
        
        return self.send_message(
            chat_id=to_chat_id,
            sender_id=sender_id,
            content=original.content,
            message_type=MessageType.FORWARD,
            forward_from=message_id
        )
    
    def add_reaction(
        self,
        message_id: str,
        user_id: str,
        emoji: str
    ) -> bool:
        """添加反应"""
        if message_id not in self._messages:
            return False
        
        message = self._messages[message_id]
        
        # 移除之前的相同反应
        message.reactions = [
            r for r in message.reactions
            if r.get("user_id") != user_id or r.get("emoji") != emoji
        ]
        
        # 添加新反应
        message.reactions.append({
            "user_id": user_id,
            "emoji": emoji,
            "timestamp": time.time()
        })
        
        self._trigger("reaction_added", {"message": message, "emoji": emoji})
        return True
    
    def pin_message(self, chat_id: str, message_id: str) -> bool:
        """置顶消息"""
        if chat_id not in self._pinned:
            self._pinned[chat_id] = []
        
        if message_id not in self._pinned[chat_id]:
            self._pinned[chat_id].append(message_id)
        
        return True
    
    def unpin_message(self, chat_id: str, message_id: str) -> bool:
        """取消置顶"""
        if chat_id in self._pinned:
            if message_id in self._pinned[chat_id]:
                self._pinned[chat_id].remove(message_id)
        return True
    
    def get_pinned(self, chat_id: str) -> List[AdvancedMessage]:
        """获取置顶消息"""
        if chat_id not in self._pinned:
            return []
        
        return [
            self._messages[mid]
            for mid in self._pinned[chat_id]
            if mid in self._messages
        ]
    
    def save_draft(self, chat_id: str, content: str) -> None:
        """保存草稿"""
        self._drafts[chat_id] = content
    
    def get_draft(self, chat_id: str) -> Optional[str]:
        """获取草稿"""
        return self._drafts.get(chat_id)
    
    def clear_draft(self, chat_id: str) -> None:
        """清除草稿"""
        if chat_id in self._drafts:
            del self._drafts[chat_id]
    
    def register_callback(self, event: str, callback: Callable) -> None:
        """注册回调"""
        if event not in self._callbacks:
            self._callbacks[event] = []
        self._callbacks[event].append(callback)
    
    def _trigger(self, event: str, data: Any) -> None:
        """触发回调"""
        if event in self._callbacks:
            for callback in self._callbacks[event]:
                try:
                    callback(data)
                except Exception as e:
                    print(f"Callback error: {e}")


# ==================== 阅后即焚 ====================

class BurnManager:
    """阅后即焚管理器"""
    
    def __init__(self):
        self._burn_queue: List[AdvancedMessage] = []
        self._burn_timers: Dict[str, asyncio.Task] = {}
    
    async def mark_as_read(self, message: AdvancedMessage) -> None:
        """标记为已读"""
        if not message.burn_after_read:
            return
        
        # 启动焚毁计时器 (默认30秒)
        message.burn_at = time.time() + 30
        
        async def burn_after_timer():
            await asyncio.sleep(30)
            await self._burn_message(message.message_id)
        
        self._burn_timers[message.message_id] = asyncio.create_task(burn_after_timer())
    
    async def _burn_message(self, message_id: str) -> None:
        """焚毁消息"""
        # 从所有消息中移除
        # 实际实现中会彻底删除
        print(f"Message burned: {message_id}")
    
    def cancel_burn(self, message_id: str) -> None:
        """取消焚毁"""
        if message_id in self._burn_timers:
            self._burn_timers[message_id].cancel()
            del self._burn_timers[message_id]


# ==================== 定时消息 ====================

class ScheduledMessageManager:
    """定时消息管理器"""
    
    def __init__(self):
        self._scheduled: Dict[str, AdvancedMessage] = {}
        self._timers: Dict[str, asyncio.Task] = {}
        self._running = True
    
    def schedule_message(
        self,
        message: AdvancedMessage,
        send_callback: Callable
    ) -> bool:
        """定时发送消息"""
        if not message.scheduled_at or message.scheduled_at <= time.time():
            return False
        
        self._scheduled[message.message_id] = message
        
        delay = message.scheduled_at - time.time()
        
        async def send_later():
            await asyncio.sleep(delay)
            if self._running and message.message_id in self._scheduled:
                await send_callback(message)
                del self._scheduled[message.message_id]
        
        self._timers[message.message_id] = asyncio.create_task(send_later())
        return True
    
    def cancel_scheduled(self, message_id: str) -> bool:
        """取消定时消息"""
        if message_id in self._timers:
            self._timers[message_id].cancel()
            del self._timers[message_id]
        
        if message_id in self._scheduled:
            del self._scheduled[message_id]
        
        return True
    
    def get_scheduled(self) -> List[AdvancedMessage]:
        """获取所有定时消息"""
        return list(self._scheduled.values())
    
    def stop(self) -> None:
        """停止"""
        self._running = False
        for timer in self._timers.values():
            timer.cancel()


# ==================== 提醒功能 ====================

@dataclass
class Reminder:
    """提醒"""
    reminder_id: str
    user_id: str
    message_id: str
    content: str
    remind_at: float
    created_at: float = field(default_factory=time.time)
    completed: bool = False


class ReminderManager:
    """提醒管理器"""
    
    def __init__(self):
        self._reminders: Dict[str, Reminder] = {}
        self._timers: Dict[str, asyncio.Task] = {}
        self._callbacks: List[Callable] = []
    
    def create_reminder(
        self,
        user_id: str,
        message_id: str,
        content: str,
        remind_at: float
    ) -> Reminder:
        """创建提醒"""
        reminder = Reminder(
            reminder_id=str(uuid.uuid4()),
            user_id=user_id,
            message_id=message_id,
            content=content,
            remind_at=remind_at
        )
        
        self._reminders[reminder.reminder_id] = reminder
        
        # 设置定时器
        delay = remind_at - time.time()
        if delay > 0:
            async def remind():
                await asyncio.sleep(delay)
                await self._trigger_reminder(reminder)
            
            self._timers[reminder.reminder_id] = asyncio.create_task(remind())
        
        return reminder
    
    async def _trigger_reminder(self, reminder: Reminder) -> None:
        """触发提醒"""
        reminder.completed = True
        
        for callback in self._callbacks:
            try:
                await callback(reminder)
            except Exception as e:
                print(f"Reminder callback error: {e}")
    
    def cancel_reminder(self, reminder_id: str) -> bool:
        """取消提醒"""
        if reminder_id in self._timers:
            self._timers[reminder_id].cancel()
            del self._timers[reminder_id]
        
        if reminder_id in self._reminders:
            del self._reminders[reminder_id]
        
        return True
    
    def get_user_reminders(self, user_id: str) -> List[Reminder]:
        """获取用户提醒"""
        return [
            r for r in self._reminders.values()
            if r.user_id == user_id and not r.completed
        ]
    
    def register_callback(self, callback: Callable) -> None:
        """注册回调"""
        self._callbacks.append(callback)


# ==================== 引用消息 ====================

class QuoteManager:
    """引用管理器"""
    
    def __init__(self):
        self._quoted_messages: Dict[str, List[str]] = {}  # message_id -> quoted_message_ids
    
    def quote_message(self, message_id: str, quoted_message_id: str) -> bool:
        """引用消息"""
        if message_id not in self._quoted_messages:
            self._quoted_messages[message_id] = []
        
        self._quoted_messages[message_id].append(quoted_message_id)
        return True
    
    def get_quoted_messages(self, message_id: str) -> List[str]:
        """获取被引用的消息"""
        return self._quoted_messages.get(message_id, [])


# ==================== 消息搜索 ====================

class MessageSearch:
    """消息搜索"""
    
    def __init__(self, message_manager: MessageManager):
        self._manager = message_manager
        self._index: Dict[str, List[str]] = {}  # word -> message_ids
    
    def index_message(self, message: AdvancedMessage) -> None:
        """索引消息"""
        # 简单分词
        words = message.content.lower().split()
        
        for word in words:
            if word not in self._index:
                self._index[word] = []
            if message.message_id not in self._index[word]:
                self._index[word].append(message.message_id)
    
    def search(self, query: str, chat_id: str = None, limit: int = 50) -> List[AdvancedMessage]:
        """搜索消息"""
        words = query.lower().split()
        results = set()
        
        for word in words:
            if word in self._index:
                results.update(self._index[word])
        
        # 过滤
        messages = []
        for mid in results:
            if mid in self._manager._messages:
                msg = self._manager._messages[mid]
                if chat_id and msg.chat_id != chat_id:
                    continue
                messages.append(msg)
        
        return messages[:limit]


# ==================== 离线消息 ====================

class OfflineMessageManager:
    """离线消息管理器"""
    
    def __init__(self):
        self._offline_queue: Dict[str, List[AdvancedMessage]] = {}  # user_id -> messages
        self._sync_state: Dict[str, float] = {}  # user_id -> last_sync_time
    
    def queue_offline_message(self, user_id: str, message: AdvancedMessage) -> None:
        """队列离线消息"""
        if user_id not in self._offline_queue:
            self._offline_queue[user_id] = []
        
        self._offline_queue[user_id].append(message)
    
    def get_offline_messages(self, user_id: str) -> List[AdvancedMessage]:
        """获取离线消息"""
        messages = self._offline_queue.get(user_id, [])
        self._offline_queue[user_id] = []
        
        # 更新同步时间
        self._sync_state[user_id] = time.time()
        
        return messages
    
    def get_pending_count(self, user_id: str) -> int:
        """获取待同步数量"""
        return len(self._offline_queue.get(user_id, []))
    
    def get_last_sync_time(self, user_id: str) -> Optional[float]:
        """获取最后同步时间"""
        return self._sync_state.get(user_id)


# ==================== 加密消息 ====================

class EncryptionManager:
    """加密管理器"""
    
    def __init__(self):
        self._keys: Dict[str, str] = {}  # user_id -> public_key
    
    def generate_keypair(self) -> tuple:
        """生成密钥对"""
        # 简化实现
        import hashlib
        key = str(time.time())
        private = hashlib.sha256(key.encode()).hexdigest()
        public = hashlib.sha256(private.encode()).hexdigest()
        return (private, public)
    
    def set_public_key(self, user_id: str, public_key: str) -> None:
        """设置公钥"""
        self._keys[user_id] = public_key
    
    def encrypt_message(self, content: str, recipient_id: str) -> Optional[str]:
        """加密消息"""
        if recipient_id not in self._keys:
            return None
        
        # 简化加密
        import base64
        return base64.b64encode(content.encode()).decode()
    
    def decrypt_message(self, encrypted: str) -> str:
        """解密消息"""
        import base64
        return base64.b64decode(encrypted.encode()).decode()


# 全局实例
message_manager = MessageManager()
burn_manager = BurnManager()
scheduled_manager = ScheduledMessageManager()
reminder_manager = ReminderManager()
offline_manager = OfflineMessageManager()
encryption_manager = EncryptionManager()
