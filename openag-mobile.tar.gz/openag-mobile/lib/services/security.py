"""
Security System - 安全系统

实现:
- 生物特征认证
- 指纹/面容ID
- 安全键盘
- 反钓鱼
- 设备管理
- 登录日志
"""

import time
import hashlib
import asyncio
from enum import Enum
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


class AuthType(str, Enum):
    """认证类型"""
    PASSWORD = "password"
    FINGERPRINT = "fingerprint"
    FACE = "face"
    BIOMETRIC = "biometric"
    PIN = "pin"
    GENE = "gene"


class AuthLevel(str, Enum):
    """认证级别"""
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class BiometricData:
    """生物特征数据"""
    gene_id: str
    gene_hash: str
    hardware_signature: str
    created_at: float = field(default_factory=time.time)
    last_verified: float = None


@dataclass
class LoginLog:
    """登录日志"""
    log_id: str
    user_id: str
    device_id: str
    ip_address: str
    location: str
    timestamp: float = field(default_factory=time.time)
    success: bool = True
    method: str = "password"


@dataclass
class TrustedDevice:
    """可信设备"""
    device_id: str
    name: str
    platform: str
    added_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    trusted: bool = True


class SecurityManager:
    """安全管理器"""
    
    def __init__(self):
        self._biometrics: Dict[str, BiometricData] = {}
        self._login_logs: List[LoginLog] = []
        self._trusted_devices: Dict[str, TrustedDevice] = {}
        self._failed_attempts: Dict[str, int] = {}
        self._lockout_until: Dict[str, float] = {}
    
    # ========== 生物特征 ==========
    def register_biometric(
        self,
        user_id: str,
        biometric_data: str,
        hardware_signature: str
    ) -> str:
        """注册生物特征"""
        gene_hash = hashlib.sha256(biometric_data.encode()).hexdigest()
        
        biometric = BiometricData(
            gene_id=f"gene_{user_id}_{int(time.time())}",
            gene_hash=gene_hash,
            hardware_signature=hardware_signature
        )
        
        self._biometrics[user_id] = biometric
        return biometric.gene_id
    
    def verify_biometric(
        self,
        user_id: str,
        biometric_data: str
    ) -> bool:
        """验证生物特征"""
        if user_id not in self._biometrics:
            return False
        
        stored = self._biometrics[user_id]
        input_hash = hashlib.sha256(biometric_data.encode()).hexdigest()
        
        return stored.gene_hash == input_hash
    
    def get_biometric(self, user_id: str) -> Optional[BiometricData]:
        """获取生物特征"""
        return self._biometrics.get(user_id)
    
    def delete_biometric(self, user_id: str) -> bool:
        """删除生物特征"""
        if user_id in self._biometrics:
            del self._biometrics[user_id]
            return True
        return False
    
    # ========== 登录日志 ==========
    def add_login_log(
        self,
        user_id: str,
        device_id: str,
        ip_address: str,
        location: str,
        success: bool,
        method: str = "password"
    ) -> LoginLog:
        """添加登录日志"""
        log = LoginLog(
            log_id=f"log_{int(time.time() * 1000)}",
            user_id=user_id,
            device_id=device_id,
            ip_address=ip_address,
            location=location,
            success=success,
            method=method
        )
        
        self._login_logs.append(log)
        
        # 记录失败尝试
        if not success:
            self._failed_attempts[user_id] = self._failed_attempts.get(user_id, 0) + 1
            
            # 锁定账户
            if self._failed_attempts[user_id] >= 5:
                self._lockout_until[user_id] = time.time() + 300  # 5分钟
        else:
            self._failed_attempts[user_id] = 0
        
        return log
    
    def get_login_logs(
        self,
        user_id: str,
        limit: int = 50
    ) -> List[LoginLog]:
        """获取登录日志"""
        logs = [l for l in self._login_logs if l.user_id == user_id]
        logs.sort(key=lambda x: x.timestamp, reverse=True)
        return logs[:limit]
    
    def get_failed_attempts(self, user_id: str) -> int:
        """获取失败尝试次数"""
        return self._failed_attempts.get(user_id, 0)
    
    def is_locked_out(self, user_id: str) -> bool:
        """检查是否锁定"""
        if user_id not in self._lockout_until:
            return False
        
        if time.time() > self._lockout_until[user_id]:
            del self._lockout_until[user_id]
            return False
        
        return True
    
    def get_lockout_remaining(self, user_id: str) -> int:
        """获取锁定剩余时间"""
        if user_id not in self._lockout_until:
            return 0
        
        remaining = self._lockout_until[user_id] - time.time()
        return max(0, int(remaining))
    
    # ========== 设备管理 ==========
    def add_trusted_device(
        self,
        device_id: str,
        name: str,
        platform: str
    ) -> TrustedDevice:
        """添加可信设备"""
        device = TrustedDevice(
            device_id=device_id,
            name=name,
            platform=platform
        )
        
        self._trusted_devices[device_id] = device
        return device
    
    def remove_trusted_device(self, device_id: str) -> bool:
        """移除可信设备"""
        if device_id in self._trusted_devices:
            del self._trusted_devices[device_id]
            return True
        return False
    
    def is_trusted_device(self, device_id: str) -> bool:
        """检查是否可信设备"""
        device = self._trusted_devices.get(device_id)
        return device and device.trusted
    
    def get_trusted_devices(self) -> List[TrustedDevice]:
        """获取可信设备列表"""
        return list(self._trusted_devices.values())
    
    def update_device_usage(self, device_id: str) ->更新设备使用时间"""
        bool:
        """ if device_id in self._trusted_devices:
            self._trusted_devices[device_id].last_used = time.time()
            return True
        return False
    
    # ========== 安全验证 ==========
    def validate_password_strength(self, password: str) -> Dict[str, Any]:
        """验证密码强度"""
        score = 0
        feedback = []
        
        if len(password) >= 8:
            score += 1
        else:
            feedback.append("密码长度至少8位")
        
        if any(c.isupper() for c in password):
            score += 1
        else:
            feedback.append("建议包含大写字母")
        
        if any(c.islower() for c in password):
            score += 1
        else:
            feedback.append("建议包含小写字母")
        
        if any(c.isdigit() for c in password):
            score += 1
        else:
            feedback.append("建议包含数字")
        
        if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            score += 1
        
        strength = ["极弱", "弱", "一般", "强", "非常强"][min(score, 4)]
        
        return {
            "score": score,
            "strength": strength,
            "valid": score >= 3,
            "feedback": feedback
        }
    
    def check_phishing(self, url: str, domain: str) -> bool:
        """反钓鱼检查"""
        # 简化实现
        suspicious_patterns = ["login", "signin", "verify", "secure", "account"]
        
        url_lower = url.lower()
        for pattern in suspicious_patterns:
            if pattern in url_lower and pattern not in domain.lower():
                return True
        
        return False
    
    def generate_secure_token(self, length: int = 32) -> str:
        """生成安全令牌"""
        import secrets
        return secrets.token_urlsafe(length)


# ========== 安全键盘 ==========

class SecureKeyboard:
    """安全键盘"""
    
    def __init__(self):
        self._enabled = True
        self._random_layout = True
    
    def is_enabled(self) -> bool:
        return self._enabled
    
    def enable(self) -> None:
        self._enabled = True
    
    def disable(self) -> None:
        self._enabled = False
    
    def should_randomize(self) -> bool:
        return self._random_layout


# 全局实例
security_manager = SecurityManager()
secure_keyboard = SecureKeyboard()
