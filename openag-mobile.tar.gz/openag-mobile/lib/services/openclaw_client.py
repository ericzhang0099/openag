"""
OpenClaw Client - 连接本地OpenClaw

实现:
- 发现本地OpenClaw服务
- WebSocket连接
- 命令发送与响应
- 状态同步
"""

import json
import asyncio
import time
import uuid
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field


class ConnectionState(str, Enum):
    """连接状态"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"


class CommandType(str, Enum):
    """命令类型"""
    PING = "ping"
    LIST_AGENTS = "list_agents"
    SEND_MESSAGE = "send_message"
    GET_STATUS = "get_status"
    EXECUTE_TASK = "execute_task"
    GET_MEMORY = "get_memory"
    UPDATE_MEMORY = "update_memory"
    CREATE_SESSION = "create_session"


@dataclass
class OpenClawAgent:
    """OpenClaw Agent"""
    agent_id: str
    name: str
    status: str = "idle"
    last_active: float = field(default_factory=time.time)
    capabilities: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Command:
    """命令"""
    command_id: str
    command_type: CommandType
    payload: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    timeout: float = 30.0
    
    def __post_init__(self):
        if not self.command_id:
            self.command_id = str(uuid.uuid4())
    
    def to_dict(self) -> Dict:
        return {
            "command_id": self.command_id,
            "command_type": self.command_type.value,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "timeout": self.timeout
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: Dict) -> "Command":
        return cls(
            command_id=data.get("command_id", ""),
            command_type=CommandType(data.get("command_type", "ping")),
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", time.time()),
            timeout=data.get("timeout", 30.0)
        )


@dataclass
class CommandResponse:
    """命令响应"""
    command_id: str
    success: bool
    data: Any = None
    error: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict:
        return {
            "command_id": self.command_id,
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "timestamp": self.timestamp
        }


class ServiceDiscovery:
    """服务发现"""
    
    def __init__(self):
        self._discovered: List[Dict[str, Any]] = []
    
    async def discover(self, timeout: float = 5.0) -> List[Dict[str, Any]]:
        """发现服务"""
        # 模拟发现本地服务
        # 实际实现中会扫描局域网或使用mDNS
        services = [
            {
                "host": "localhost",
                "port": 8080,
                "name": "OpenClaw Gateway",
                "version": "1.0.0"
            }
        ]
        
        self._discovered = services
        return services
    
    def get_cached(self) -> List[Dict[str, Any]]:
        """获取缓存的服务"""
        return self._discovered


class OpenClawClient:
    """OpenClaw客户端"""
    
    def __init__(self):
        self._state = ConnectionState.DISCONNECTED
        self._host: Optional[str] = None
        self._port: Optional[int] = None
        self._ws = None
        self._handlers: Dict[str, Callable] = {}
        self._pending_commands: Dict[str, asyncio.Future] = {}
        self._agents: Dict[str, OpenClawAgent] = {}
        self._callbacks: Dict[str, List[Callable]] = {}
        self._reconnect_attempts = 0
        self._max_reconnect = 5
    
    @property
    def state(self) -> ConnectionState:
        return self._state
    
    @property
    def is_connected(self) -> bool:
        return self._state == ConnectionState.CONNECTED
    
    async def connect(self, host: str, port: int) -> bool:
        """连接"""
        self._host = host
        self._port = port
        self._state = ConnectionState.CONNECTING
        
        try:
            # 模拟WebSocket连接
            # 实际使用: web_socket_channel.IOWebSocketChannel
            await asyncio.sleep(0.5)  # 模拟连接延迟
            
            self._state = ConnectionState.CONNECTED
            self._reconnect_attempts = 0
            
            # 触发连接回调
            await self._trigger_callback("connected", None)
            
            # 启动心跳
            asyncio.create_task(self._heartbeat_loop())
            
            # 获取Agent列表
            await self.list_agents()
            
            return True
            
        except Exception as e:
            self._state = ConnectionState.DISCONNECTED
            return False
    
    async def disconnect(self) -> None:
        """断开连接"""
        self._state = ConnectionState.DISCONNECTED
        self._ws = None
        await self._trigger_callback("disconnected", None)
    
    async def reconnect(self) -> bool:
        """重连"""
        if not self._host or not self._port:
            return False
        
        if self._reconnect_attempts >= self._max_reconnect:
            return False
        
        self._state = ConnectionState.RECONNECTING
        self._reconnect_attempts += 1
        
        await asyncio.sleep(2 ** self._reconnect_attempts)  # 指数退避
        
        return await self.connect(self._host, self._port)
    
    async def send_command(
        self,
        command: Command,
        wait_response: bool = True
    ) -> Optional[CommandResponse]:
        """发送命令"""
        if not self.is_connected:
            return None
        
        # 发送命令
        # 实际使用: self._ws.add(json.dumps(command.to_dict()))
        
        if not wait_response:
            return CommandResponse(
                command_id=command.command_id,
                success=True
            )
        
        # 等待响应
        future = asyncio.Future()
        self._pending_commands[command.command_id] = future
        
        try:
            response = await asyncio.wait_for(
                future,
                timeout=command.timeout
            )
            return response
        except asyncio.TimeoutError:
            return CommandResponse(
                command_id=command.command_id,
                success=False,
                error="Timeout"
            )
        finally:
            if command.command_id in self._pending_commands:
                del self._pending_commands[command.command_id]
    
    async def ping(self) -> bool:
        """Ping"""
        cmd = Command(
            command_type=CommandType.PING,
            payload={}
        )
        response = await self.send_command(cmd)
        return response.success if response else False
    
    async def list_agents(self) -> List[OpenClawAgent]:
        """列出Agent"""
        cmd = Command(
            command_type=CommandType.LIST_AGENTS,
            payload={}
        )
        response = await self.send_command(cmd)
        
        if response and response.success and response.data:
            agents = []
            for agent_data in response.data:
                agent = OpenClawAgent(
                    agent_id=agent_data.get("agent_id", ""),
                    name=agent_data.get("name", ""),
                    status=agent_data.get("status", "idle"),
                    capabilities=agent_data.get("capabilities", [])
                )
                agents.append(agent)
                self._agents[agent.agent_id] = agent
            
            return agents
        
        return []
    
    async def get_agent_status(self, agent_id: str) -> Optional[Dict]:
        """获取Agent状态"""
        cmd = Command(
            command_type=CommandType.GET_STATUS,
            payload={"agent_id": agent_id}
        )
        response = await self.send_command(cmd)
        
        if response and response.success:
            return response.data
        return None
    
    async def send_message_to_agent(
        self,
        agent_id: str,
        message: str
    ) -> bool:
        """发送消息给Agent"""
        cmd = Command(
            command_type=CommandType.SEND_MESSAGE,
            payload={
                "agent_id": agent_id,
                "message": message
            }
        )
        response = await self.send_command(cmd)
        return response.success if response else False
    
    async def execute_task(
        self,
        agent_id: str,
        task: str,
        params: Optional[Dict] = None
    ) -> Optional[Any]:
        """执行任务"""
        cmd = Command(
            command_type=CommandType.EXECUTE_TASK,
            payload={
                "agent_id": agent_id,
                "task": task,
                "params": params or {}
            }
        )
        response = await self.send_command(cmd)
        
        if response and response.success:
            return response.data
        return None
    
    async def get_memory(self, agent_id: str) -> Optional[Dict]:
        """获取Agent内存"""
        cmd = Command(
            command_type=CommandType.GET_MEMORY,
            payload={"agent_id": agent_id}
        )
        response = await self.send_command(cmd)
        
        if response and response.success:
            return response.data
        return None
    
    def register_callback(self, event: str, callback: Callable) -> None:
        """注册回调"""
        if event not in self._callbacks:
            self._callbacks[event] = []
        self._callbacks[event].append(callback)
    
    async def _trigger_callback(self, event: str, data: Any) -> None:
        """触发回调"""
        if event in self._callbacks:
            for callback in self._callbacks[event]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(data)
                    else:
                        callback(data)
                except Exception as e:
                    pass
    
    async def _heartbeat_loop(self) -> None:
        """心跳循环"""
        while self.is_connected:
            try:
                await self.ping()
                await asyncio.sleep(30)
            except Exception:
                break
        
        # 断开则尝试重连
        if self._state == ConnectionState.CONNECTED:
            await self.reconnect()
    
    def get_agents(self) -> List[OpenClawAgent]:
        """获取Agent列表"""
        return list(self._agents.values())
    
    def get_agent(self, agent_id: str) -> Optional[OpenClawAgent]:
        """获取指定Agent"""
        return self._agents.get(agent_id)
    
    def get_status(self) -> Dict[str, Any]:
        """获取状态"""
        return {
            "state": self._state.value,
            "host": self._host,
            "port": self._port,
            "agents_count": len(self._agents),
            "reconnect_attempts": self._reconnect_attempts
        }


class OpenClawService:
    """OpenClaw服务管理器"""
    
    def __init__(self):
        self.discovery = ServiceDiscovery()
        self._clients: Dict[str, OpenClawClient] = {}
        self._default_client: Optional[OpenClawClient] = None
    
    async def discover_local(self) -> List[Dict[str, Any]]:
        """发现本地服务"""
        return await self.discovery.discover()
    
    async def connect(
        self,
        host: str = "localhost",
        port: int = 8080,
        name: Optional[str] = None
    ) -> OpenClawClient:
        """连接"""
        key = f"{host}:{port}"
        
        client = OpenClawClient()
        success = await client.connect(host, port)
        
        if success:
            self._clients[key] = client
            if not self._default_client:
                self._default_client = client
            return client
        
        return None
    
    async def disconnect(self, key: str) -> None:
        """断开连接"""
        if key in self._clients:
            await self._clients[key].disconnect()
            del self._clients[key]
    
    def get_client(self, key: str) -> Optional[OpenClawClient]:
        """获取客户端"""
        return self._clients.get(key)
    
    def get_default_client(self) -> Optional[OpenClawClient]:
        """获取默认客户端"""
        return self._default_client
    
    def list_clients(self) -> List[str]:
        """列出所有客户端"""
        return list(self._clients.keys())
    
    def get_all_agents(self) -> List[OpenClawAgent]:
        """获取所有Agent"""
        agents = []
        for client in self._clients.values():
            agents.extend(client.get_agents())
        return agents
