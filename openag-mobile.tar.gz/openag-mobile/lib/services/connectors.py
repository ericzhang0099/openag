"""
OpenClaw Connectors - 连接器

支持两种连接方式:
1. OpenClaw原生WebSocket
2. 模拟飞书/Telegram Bot API
"""

import json
import asyncio
import time
import uuid
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


class ConnectionType(str, Enum):
    """连接类型"""
    OPENCLAW_WS = "openclaw_ws"      # OpenClaw WebSocket
    FEISHU_BOT = "feishu_bot"         # 飞书Bot
    TELEGRAM_BOT = "telegram_bot"     # Telegram Bot


@dataclass
class AgentProfile:
    """Agent档案"""
    agent_id: str
    name: str
    avatar: Optional[str] = None
    bio: Optional[str] = None
    gene_hash: Optional[str] = None  # 生物特征哈希
    status: str = "online"
    last_seen: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Message:
    """消息"""
    message_id: str
    sender_id: str
    receiver_id: str
    message_type: str = "text"  # text, image, file, audio
    content: str
    timestamp: float = field(default_factory=time.time)
    read: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Group:
    """群组"""
    group_id: str
    name: str
    owner_id: str
    members: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


# ==================== OpenClaw WebSocket Connector ====================

class OpenClawWSConnector:
    """OpenClaw WebSocket连接器"""
    
    def __init__(self):
        self._connected = False
        self._host: Optional[str] = None
        self._port: Optional[int] = None
        self._ws = None
        self._callbacks: Dict[str, List[Callable]] = {}
        self._pending: Dict[str, asyncio.Future] = {}
        self._agent: Optional[AgentProfile] = None
    
    @property
    def is_connected(self) -> bool:
        return self._connected
    
    async def connect(self, host: str, port: int) -> bool:
        """连接OpenClaw"""
        self._host = host
        self._port = port
        
        try:
            # 模拟WebSocket连接
            # 实际使用: websockets.connect(f"ws://{host}:{port}")
            await asyncio.sleep(0.3)
            
            self._connected = True
            logger.info(f"Connected to OpenClaw: {host}:{port}")
            
            # 启动心跳
            asyncio.create_task(self._heartbeat())
            
            return True
        except Exception as e:
            logger.error(f"Connection failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """断开连接"""
        self._connected = False
        self._ws = None
    
    async def send(self, method: str, params: Dict = None) -> Optional[Dict]:
        """发送请求"""
        if not self._connected:
            return None
        
        request_id = str(uuid.uuid4())
        
        # 模拟发送
        # 实际: await self._ws.send(json.dumps({...}))
        
        # 模拟响应
        await asyncio.sleep(0.1)
        
        return {
            "id": request_id,
            "result": {},
            "error": None
        }
    
    async def register_agent(self, profile: AgentProfile) -> bool:
        """注册Agent"""
        result = await self.send("agent.register", {
            "agent_id": profile.agent_id,
            "name": profile.name,
            "gene_hash": profile.gene_hash
        })
        
        if result and not result.get("error"):
            self._agent = profile
            return True
        return False
    
    async def get_agents(self) -> List[AgentProfile]:
        """获取Agent列表"""
        result = await self.send("agent.list")
        
        agents = []
        if result and result.get("result"):
            for data in result["result"]:
                agents.append(AgentProfile(
                    agent_id=data.get("agent_id", ""),
                    name=data.get("name", ""),
                    status=data.get("status", "offline")
                ))
        
        return agents
    
    async def send_message(self, to_agent_id: str, content: str) -> bool:
        """发送消息"""
        result = await self.send("message.send", {
            "to": to_agent_id,
            "content": content
        })
        
        return result and not result.get("error")
    
    async def on_message(self, callback: Callable) -> None:
        """消息回调"""
        if "message" not in self._callbacks:
            self._callbacks["message"] = []
        self._callbacks["message"].append(callback)
    
    async def _heartbeat(self) -> None:
        """心跳"""
        while self._connected:
            await asyncio.sleep(30)
            if self._connected:
                await self.send("ping")
    
    def get_status(self) -> Dict:
        return {
            "connected": self._connected,
            "host": self._host,
            "port": self._port,
            "agent": self._agent.agent_id if self._agent else None
        }


# ==================== Feishu Bot Connector ====================

class FeishuBotConnector:
    """飞书Bot连接器"""
    
    def __init__(self):
        self._app_id: Optional[str] = None
        self._app_secret: Optional[str] = None
        self._verification_token: Optional[str] = None
        self._webhook_url: Optional[str] = None
        self._callbacks: Dict[str, List[Callable]] = {}
        self._agent: Optional[AgentProfile] = None
    
    def configure(
        self,
        app_id: str,
        app_secret: str,
        verification_token: str = None
    ) -> None:
        """配置飞书应用"""
        self._app_id = app_id
        self._app_secret = app_secret
        self._verification_token = verification_token
    
    def get_webhook_url(self, user_id: str) -> str:
        """获取Webhook URL"""
        return f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=user_id"
    
    async def send_message(
        self,
        user_id: str,
        content: str,
        msg_type: str = "text"
    ) -> bool:
        """发送消息"""
        # 模拟发送
        logger.info(f"Feishu: Sending {msg_type} to {user_id}")
        return True
    
    async def send_card(
        self,
        user_id: str,
        title: str,
        content: str,
        buttons: List[Dict] = None
    ) -> bool:
        """发送卡片消息"""
        card = {
            "config": {"wide_screen_mode": True},
            "header": {"title": {"tag": "plain_text", "content": title}},
            "elements": [
                {
                    "tag": "markdown",
                    "content": content
                }
            ]
        }
        
        if buttons:
            button_elements = []
            for btn in buttons:
                button_elements.append({
                    "tag": "button",
                    "text": {"tag": "plain_text", "content": btn["text"]},
                    "type": "primary" if btn.get("primary") else "default",
                    "action": {"type": "request", "data": btn.get("data", {})}
                })
            card["elements"].extend(button_elements)
        
        logger.info(f"Feishu: Sending card to {user_id}")
        return True
    
    async def send_reply(self, message_id: str, content: str) -> bool:
        """回复消息"""
        logger.info(f"Feishu: Replying to {message_id}")
        return True
    
    async def get_user_info(self, user_id: str) -> Optional[Dict]:
        """获取用户信息"""
        return {
            "user_id": user_id,
            "name": "User",
            "avatar": None
        }
    
    def on_event(self, event_type: str, callback: Callable) -> None:
        """注册事件回调"""
        if event_type not in self._callbacks:
            self._callbacks[event_type] = []
        self._callbacks[event_type].append(callback)
    
    async def handle_webhook(self, payload: Dict) -> None:
        """处理Webhook事件"""
        event_type = payload.get("type")
        
        if event_type in self._callbacks:
            for callback in self._callbacks[event_type]:
                await callback(payload)
    
    def verify_webhook(self, challenge: str, signature: str) -> bool:
        """验证Webhook"""
        # 简化验证
        return True
    
    def get_status(self) -> Dict:
        return {
            "type": ConnectionType.FEISHU_BOT.value,
            "configured": self._app_id is not None,
            "agent": self._agent.agent_id if self._agent else None
        }


# ==================== Telegram Bot Connector ====================

class TelegramBotConnector:
    """Telegram Bot连接器"""
    
    def __init__(self):
        self._bot_token: Optional[str] = None
        self._api_url: Optional[str] = None
        self._callbacks: Dict[str, List[Callable]] = {}
        self._agent: Optional[AgentProfile] = None
    
    def configure(self, bot_token: str) -> None:
        """配置Telegram Bot"""
        self._bot_token = bot_token
        self._api_url = f"https://api.telegram.org/bot{bot_token}"
    
    async def send_message(
        self,
        chat_id: str,
        text: str,
        parse_mode: str = "Markdown",
        reply_markup: Dict = None
    ) -> bool:
        """发送消息"""
        logger.info(f"Telegram: Sending message to {chat_id}")
        return True
    
    async def send_photo(
        self,
        chat_id: str,
        photo_url: str,
        caption: str = None
    ) -> bool:
        """发送图片"""
        logger.info(f"Telegram: Sending photo to {chat_id}")
        return True
    
    async def send_document(
        self,
        chat_id: str,
        document_url: str,
        caption: str = None
    ) -> bool:
        """发送文件"""
        logger.info(f"Telegram: Sending document to {chat_id}")
        return True
    
    async def send_buttons(
        self,
        chat_id: str,
        text: str,
        buttons: List[List[Dict]]
    ) -> bool:
        """发送按钮"""
        keyboard = {
            "inline_keyboard": buttons
        }
        
        logger.info(f"Telegram: Sending buttons to {chat_id}")
        return True
    
    async def set_webhook(self, url: str) -> bool:
        """设置Webhook"""
        logger.info(f"Telegram: Setting webhook to {url}")
        return True
    
    def on_message(self, callback: Callable) -> None:
        """消息回调"""
        if "message" not in self._callbacks:
            self._callbacks["message"] = []
        self._callbacks["message"].append(callback)
    
    async def handle_update(self, update: Dict) -> None:
        """处理更新"""
        if "message" in self._callbacks:
            for callback in self._callbacks["message"]:
                await callback(update["message"])
    
    def get_status(self) -> Dict:
        return {
            "type": ConnectionType.TELEGRAM_BOT.value,
            "configured": self._bot_token is not None,
            "agent": self._agent.agent_id if self._agent else None
        }


# ==================== Unified Connector ====================

class ConnectorManager:
    """连接器管理器"""
    
    def __init__(self):
        self._openclaw_ws = OpenClawWSConnector()
        self._feishu = FeishuBotConnector()
        self._telegram = TelegramBotConnector()
        self._current_connector = None
        self._connection_type: Optional[ConnectionType] = None
    
    def get_openclaw(self) -> OpenClawWSConnector:
        return self._openclaw_ws
    
    def get_feishu(self) -> FeishuBotConnector:
        return self._feishu
    
    def get_telegram(self) -> TelegramBotConnector:
        return self._telegram
    
    async def connect_openclaw(self, host: str, port: int) -> bool:
        """连接OpenClaw"""
        success = await self._openclaw_ws.connect(host, port)
        if success:
            self._current_connector = self._openclaw_ws
            self._connection_type = ConnectionType.OPENCLAW_WS
        return success
    
    def connect_feishu(
        self,
        app_id: str,
        app_secret: str,
        verification_token: str = None
    ) -> None:
        """连接飞书"""
        self._feishu.configure(app_id, app_secret, verification_token)
        self._current_connector = self._feishu
        self._connection_type = ConnectionType.FEISHU_BOT
    
    def connect_telegram(self, bot_token: str) -> None:
        """连接Telegram"""
        self._telegram.configure(bot_token)
        self._current_connector = self._telegram
        self._connection_type = ConnectionType.TELEGRAM_BOT
    
    def is_connected(self) -> bool:
        if self._current_connector:
            return getattr(self._current_connector, 'is_connected', lambda: True)()
        return False
    
    def get_status(self) -> Dict:
        return {
            "type": self._connection_type.value if self._connection_type else None,
            "openclaw": self._openclaw_ws.get_status(),
            "feishu": self._feishu.get_status(),
            "telegram": self._telegram.get_status()
        }
