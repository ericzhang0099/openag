"""
Push Notification - 推送通知

实现:
- 本地通知
- 远程推送(FCM)
- 通知管理
"""

import time
from enum import Enum
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass


class NotificationType(str, Enum):
    """通知类型"""
    MESSAGE = "message"
    TRANSFER = "transfer"
    FRIEND = "friend"
    SYSTEM = "system"
    ALERT = "alert"


class NotificationPriority(str, Enum):
    """通知优先级"""
    LOW = "low"
    DEFAULT = "default"
    HIGH = "high"
    URGENT = "urgent"


@dataclass
class Notification:
    """通知"""
    notification_id: str
    title: str
    body: str
    notification
    priority:_type: NotificationType NotificationPriority = NotificationPriority.DEFAULT
    data: Dict = None
    timestamp: float = None
    read: bool = False
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
        if self.data is None:
            self.data = {}


class NotificationManager:
    """通知管理器"""
    
    def __init__(self):
        self._notifications: List[Notification] = []
        self._listeners: List[Callable] = []
        self._enabled = True
    
    def add_notification(
        self,
        title: str,
        body: str,
        notification_type: NotificationType = NotificationType.SYSTEM,
        priority: NotificationPriority = NotificationPriority.DEFAULT,
        data: Dict = None
    ) -> Notification:
        """添加通知"""
        notification = Notification(
            notification_id=f"notif_{int(time.time() * 1000)}",
            title=title,
            body=body,
            notification_type=notification_type,
            priority=priority,
            data=data or {}
        )
        
        self._notifications.insert(0, notification)
        
        # 触发监听器
        for listener in self._listeners:
            listener(notification)
        
        return notification
    
    def get_notifications(
        self,
        notification_type: NotificationType = None,
        unread_only: bool = False,
        limit: int = 50
    ) -> List[Notification]:
        """获取通知列表"""
        result = self._notifications
        
        if notification_type:
            result = [n for n in result if n.notification_type == notification_type]
        
        if unread_only:
            result = [n for n in result if not n.read]
        
        return result[:limit]
    
    def mark_read(self, notification_id: str) -> bool:
        """标记已读"""
        for notif in self._notifications:
            if notif.notification_id == notification_id:
                notif.read = True
                return True
        return False
    
    def mark_all_read(self) -> int:
        """全部标记已读"""
        count = 0
        for notif in self._notifications:
            if not notif.read:
                notif.read = True
                count += 1
        return count
    
    def delete_notification(self, notification_id: str) -> bool:
        """删除通知"""
        for i, notif in enumerate(self._notifications):
            if notif.notification_id == notification_id:
                self._notifications.pop(i)
                return True
        return False
    
    def clear_all(self) -> None:
        """清空所有通知"""
        self._notifications.clear()
    
    def get_unread_count(self) -> int:
        """获取未读数量"""
        return sum(1 for n in self._notifications if not n.read)
    
    def add_listener(self, listener: Callable) -> None:
        """添加监听器"""
        self._listeners.append(listener)
    
    def remove_listener(self, listener: Callable) -> None:
        """移除监听器"""
        if listener in self._listeners:
            self._listeners.remove(listener)
    
    def set_enabled(self, enabled: bool) -> None:
        """设置启用状态"""
        self._enabled = enabled
    
    def is_enabled(self) -> bool:
        """获取启用状态"""
        return self._enabled
    
    # 便捷方法
    def notify_message(self, sender: str, preview: str) -> None:
        """新消息通知"""
        self.add_notification(
            title=f"新消息 from {sender}",
            body=preview,
            notification_type=NotificationType.MESSAGE,
            priority=NotificationPriority.DEFAULT,
            data={"type": "message", "sender": sender}
        )
    
    def notify_transfer(self, from_agent: str, amount: int) -> None:
        """转账通知"""
        self.add_notification(
            title="收到转账",
            body=f"从 {from_agent} 收到 {amount} AGC",
            notification_type=NotificationType.TRANSFER,
            priority=NotificationPriority.HIGH,
            data={"type": "transfer", "from": from_agent, "amount": amount}
        )
    
    def notify_friend_request(self, from_agent: str) -> None:
        """好友请求通知"""
        self.add_notification(
            title="好友请求",
            body=f"{from_agent} 请求添加您为好友",
            notification_type=NotificationType.FRIEND,
            priority=NotificationPriority.DEFAULT,
            data={"type": "friend_request", "from": from_agent}
        )


class PushService:
    """推送服务"""
    
    def __init__(self):
        self._token: Optional[str] = None
        self._initialized = False
    
    async def initialize(self, config: Dict) -> bool:
        """初始化"""
        # 实际实现中会初始化FCM或其他推送服务
        self._initialized = True
        return True
    
    async def register_token(self, token: str) -> bool:
        """注册Token"""
        self._token = token
        return True
    
    async def send_local_notification(
        self,
        notification: Notification
    ) -> bool:
        """发送本地通知"""
        if not self._initialized:
            return False
        
        # 实际实现中会调用平台API
        return True
    
    async def request_permission(self) -> bool:
        """请求权限"""
        return True
    
    def get_token(self) -> Optional[str]:
        """获取Token"""
        return self._token


# 全局实例
notification_manager = NotificationManager()
push_service = PushService()
