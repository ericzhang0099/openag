"""
Plugin System - 插件系统

实现:
- 插件加载/卸载
- 插件市场
- 插件API
- 主题插件
"""

import time
import json
import asyncio
from enum import Enum
from typing import Dict, List, Any, Callable, Optional
from dataclasses import dataclass, field


class PluginType(str, Enum):
    """插件类型"""
    THEME = "theme"
    EXTENSION = "extension"
    GAME = "game"
    TOOL = "tool"
    AI = "ai"


class PluginStatus(str, Enum):
    """插件状态"""
    INSTALLED = "installed"
    ENABLED = "enabled"
    DISABLED = "disabled"
    UPDATE_AVAILABLE = "update_available"


@dataclass
class Plugin:
    """插件"""
    plugin_id: str
    name: str
    description: str
    version: str
    author: str
    plugin_type: PluginType
    
    # 状态
    status: PluginStatus = PluginStatus.INSTALLED
    
    # 文件
    entry_point: str = ""
    icon: Optional[str] = None
    
    # 配置
    settings: Dict = field(default_factory=dict)
    
    # 权限
    permissions: List[str] = field(default_factory=list)
    
    # 统计
    installed_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)
    downloads: int = 0
    rating: float = 0.0


@dataclass
class PluginSettings:
    """插件设置"""
    plugin_id: str
    enabled: bool = False
    config: Dict = field(default_factory=dict)


class PluginAPI:
    """插件API"""
    
    def __init__(self, plugin_id: str):
        self._plugin_id = plugin_id
        self._registered_commands = []
        self._registered_handlers = []
    
    def register_command(
        self,
        name: str,
        handler: Callable,
        description: str = ""
    ) -> None:
        """注册命令"""
        self._registered_commands.append({
            "name": name,
            "handler": handler,
            "description": description
        })
    
    def register_event_handler(
        self,
        event: str,
        handler: Callable
    ) -> None:
        """注册事件处理器"""
        self._registered_handlers.append({
            "event": event,
            "handler": handler
        })
    
    def get_user_data(self, user_id: str) -> Dict:
        """获取用户数据"""
        return {}
    
    def save_user_data(self, user_id: str, data: Dict) -> bool:
        """保存用户数据"""
        return True
    
    def send_notification(self, user_id: str, message: str) -> None:
        """发送通知"""
        pass
    
    def log(self, message: str) -> None:
        """日志"""
        print(f"[Plugin {self._plugin_id}] {message}")


class PluginManager:
    """插件管理器"""
    
    def __init__(self):
        self._plugins: Dict[str, Plugin] = {}
        self._settings: Dict[str, PluginSettings] = {}
        self._plugin_apis: Dict[str, PluginAPI] = {}
        self._enabled_plugins: set = set()
        self._callbacks: Dict[str, List[Callable]] = {}
    
    # ========== 插件安装/卸载 ==========
    def install_plugin(
        self,
        name: str,
        description: str,
        version: str,
        author: str,
        plugin_type: PluginType,
        entry_point: str = ""
    ) -> Plugin:
        """安装插件"""
        plugin = Plugin(
            plugin_id=f"plugin_{int(time.time())}",
            name=name,
            description=description,
            version=version,
            author=author,
            plugin_type=plugin_type,
            entry_point=entry_point
        )
        
        self._plugins[plugin.plugin_id] = plugin
        self._settings[plugin.plugin_id] = PluginSettings(plugin_id=plugin.plugin_id)
        self._plugin_apis[plugin.plugin_id] = PluginAPI(plugin.plugin_id)
        
        return plugin
    
    def uninstall_plugin(self, plugin_id: str) -> bool:
        """卸载插件"""
        if plugin_id in self._plugins:
            # 禁用插件
            if plugin_id in self._enabled_plugins:
                self.disable_plugin(plugin_id)
            
            # 清理数据
            del self._plugins[plugin_id]
            if plugin_id in self._settings:
                del self._settings[plugin_id]
            if plugin_id in self._plugin_apis:
                del self._plugin_apis[plugin_id]
            
            return True
        return False
    
    # ========== 插件启用/禁用 ==========
    def enable_plugin(self, plugin_id: str) -> bool:
        """启用插件"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            return False
        
        # 检查权限
        if not self._check_permissions(plugin):
            return False
        
        plugin.status = PluginStatus.ENABLED
        self._enabled_plugins.add(plugin_id)
        
        if plugin_id in self._settings:
            self._settings[plugin_id].enabled = True
        
        # 触发事件
        self._trigger("plugin_enabled", plugin)
        
        return True
    
    def disable_plugin(self, plugin_id: str) -> bool:
        """禁用插件"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            return False
        
        plugin.status = PluginStatus.DISABLED
        self._enabled_plugins.discard(plugin_id)
        
        if plugin_id in self._settings:
            self._settings[plugin_id].enabled = False
        
        # 触发事件
        self._trigger("plugin_disabled", plugin)
        
        return True
    
    def _check_permissions(self, plugin: Plugin) -> bool:
        """检查权限"""
        # 简化实现
        return True
    
    # ========== 插件配置 ==========
    def get_plugin_settings(self, plugin_id: str) -> Optional[PluginSettings]:
        """获取插件设置"""
        return self._settings.get(plugin_id)
    
    def update_plugin_settings(
        self,
        plugin_id: str,
        config: Dict
    ) -> bool:
        """更新插件设置"""
        if plugin_id not in self._settings:
            return False
        
        self._settings[plugin_id].config.update(config)
        return True
    
    # ========== 插件查询 ==========
    def get_plugin(self, plugin_id: str) -> Optional[Plugin]:
        """获取插件"""
        return self._plugins.get(plugin_id)
    
    def get_all_plugins(self) -> List[Plugin]:
        """获取所有插件"""
        return list(self._plugins.values())
    
    def get_enabled_plugins(self) -> List[Plugin]:
        """获取已启用插件"""
        return [
            p for p in self._plugins.values()
            if p.plugin_id in self._enabled_plugins
        ]
    
    def get_plugins_by_type(self, plugin_type: PluginType) -> List[Plugin]:
        """按类型获取插件"""
        return [
            p for p in self._plugins.values()
            if p.plugin_type == plugin_type
        ]
    
    def search_plugins(self, query: str) -> List[Plugin]:
        """搜索插件"""
        query_lower = query.lower()
        return [
            p for p in self._plugins.values()
            if query_lower in p.name.lower() or query_lower in p.description.lower()
        ]
    
    # ========== 事件 ==========
    def register_callback(self, event: str, callback: Callable) -> None:
        """注册回调"""
        if event not in self._callbacks:
            self._callbacks[event] = []
        self._callbacks[event].append(callback)
    
    def _trigger(self, event: str, data: Any) -> None:
        """触发事件"""
        if event in self._callbacks:
            for callback in self._callbacks[event]:
                try:
                    callback(data)
                except Exception as e:
                    print(f"Plugin callback error: {e}")


# ========== 插件市场 ==========

class PluginMarket:
    """插件市场"""
    
    def __init__(self):
        self._featured_plugins: List[Plugin] = []
    
    def get_featured(self) -> List[Plugin]:
        """获取精选插件"""
        return self._featured_plugins
    
    def get_popular(self, limit: int = 10) -> List[Plugin]:
        """获取热门插件"""
        # 按下载量排序
        return sorted(
            self._featured_plugins,
            key=lambda p: p.downloads,
            reverse=True
        )[:limit]
    
    def get_new_releases(self, limit: int = 10) -> List[Plugin]:
        """获取新发布"""
        # 按时间排序
        return sorted(
            self._featured_plugins,
            key=lambda p: p.installed_at,
            reverse=True
        )[:limit]


# 全局实例
plugin_manager = PluginManager()
plugin_market = PluginMarket()
