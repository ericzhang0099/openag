# OpenAG Mobile - 移动APP规格文档

## 1. 项目概述

**项目名称**: OpenAG Mobile
**平台**: iOS + Android
**核心功能**: Agent通讯、转账、连接本地OpenClaw

---

## 2. 连接方式

### 2.1 OpenClaw原生连接 (WebSocket)
- 通过WebSocket连接本地OpenClaw Gateway
- 使用OpenClaw API进行命令发送
- 适用于本地部署场景

### 2.2 模拟飞书/Telegram Bot API
- 模拟飞书/Telegram机器人接口
- 支持Webhook接收消息
- 支持按钮、卡片等富文本消息
- 适用于云端部署场景

---

## 3. 功能需求

### 3.1 登录与Agent ID
- [ ] 用户登录 → 分配唯一Agent ID
- [ ] Agent ID = 用户的唯一标识
- [ ] 生物特征（基因片段）绑定

### 3.2 Agent发现
- [ ] 通过Agent ID搜索
- [ ] 通过生物特征（基因）搜索
- [ ] 附近Agent发现
- [ ] 推荐Agent

### 3.3 消息功能 (微信/飞书风格)
- [ ] 好友列表
- [ ] 私聊消息
- [ ] 群组聊天
- [ ] 消息类型：文本、图片、文件、语音
- [ ] 消息已读/未读
- [ ] 离线消息存储

### 3.4 转账功能 (AGC Token)
- [ ] 钱包创建/导入
- [ ] 查看余额
- [ ] 转账 (Agent to Agent)
- [ ] 交易记录
- [ ] 收款码/付款码

### 3.5 消息流程
```
用户A → 发送消息 → Agent A → 网络 → Agent B → 通知用户B
```

### 3.6 转账流程
```
用户A → 转账请求 → Agent A → 区块链 → Agent B → 用户B收到
```

---

## 3. 技术架构

```
┌─────────────────────────────────────────┐
│              Flutter UI                  │
├─────────────────────────────────────────┤
│              Business Logic             │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐  │
│  │ Agent   │ │ Wallet  │ │ OpenClaw│  │
│  │ Manager │ │ Manager │ │ Client  │  │
│  └─────────┘ └─────────┘ └─────────┘  │
├─────────────────────────────────────────┤
│            Protocol Layer               │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐  │
│  │ A2A     │ │ AGC     │ │ WS     │  │
│  │ Protocol│ │ Token   │ │ Client │  │
│  └─────────┘ └─────────┘ └─────────┘  │
├─────────────────────────────────────────┤
│              Native Layer               │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐  │
│  │ Keychain│ │ SQLite  │ │ Network│  │
│  └─────────┘ └─────────┘ └─────────┘  │
└─────────────────────────────────────────┘
```

---

## 4. 页面结构

1. **首页** - Agent列表、状态
2. **通讯** - 消息列表、聊天窗口
3. **钱包** - 余额、转账、收款码
4. **OpenClaw** - 设备列表、控制面板
5. **设置** - 网络配置、安全设置

---

## 5. 依赖库

### Flutter
- `flutter_bloc` - 状态管理
- `get_it` - 依赖注入
- `hive` - 本地存储
- `web_socket_channel` - WebSocket
- `sqflite` - SQLite
- `flutter_secure_storage` - 安全存储
- `qr_code` - 二维码
- `http` - HTTP客户端

### Dart (协议实现)
- `cryptography` - 加密
- `pointycastle` - 密码学

---

## 6. API设计

### Agent通讯
```dart
// 发送消息
Future<MessageResult> sendMessage(AgentId to, Message message);

// 接收消息
Stream<Message> onMessage(AgentId agentId);
```

### 转账
```dart
// 转账
Future<TransactionResult> transfer(AgentId to, int amount);

// 查余额
Future<int> getBalance(AgentId agentId);
```

### OpenClaw
```dart
// 连接
Future<void> connect(String host, int port);

// 发送命令
Future<Response> sendCommand(Command cmd);
```

---

## 7. 进度追踪

| 功能 | 状态 |
|------|------|
| 项目初始化 | ⏳ |
| 核心协议实现 | ⏳ |
| UI界面开发 | ⏳ |
| OpenClaw集成 | ⏳ |
| iOS构建 | ⏳ |
| Android构建 | ⏳ |
